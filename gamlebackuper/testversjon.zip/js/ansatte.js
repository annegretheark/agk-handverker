let ansatte = [];

async function lastAnsatte() {

  if (!erAdmin) return;

  const { data, error } = await supabaseClient
    .from("ansatte")
    .select("*")
    .order("epost");

  if (error) {
    console.error("Feil ved henting av ansatte:", error);
    settMelding("ansattMelding", "Feil ved henting av ansatte: " + error.message);
    ansatte = [];
    return;
  }

  ansatte = data || [];
  visAnsatte();
}

function visAnsatte() {

  const tbody = document.getElementById("ansattListe");

  if (!tbody) return;

  tbody.innerHTML = "";

  ansatte.forEach(a => {

    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${a.navn || ""}</td>
      <td>${a.epost || ""}</td>
      <td>${a.mobil || ""}</td>
      <td>${a.er_admin ? "Ja" : "Nei"}</td>
      <td>
        <button onclick="redigerAnsatt('${a.id}')">
          Rediger
        </button>

        <button class="danger"
          onclick="slettAnsatt('${a.id}')">
          Slett
        </button>
      </td>
    `;

    tbody.appendChild(tr);
  });
}

async function opprettBruker() {

  const melding = document.getElementById("ansattMelding");

  melding.textContent = "";
  melding.className = "melding";

  try {

    if (!erAdmin) {
      melding.textContent = "Bare admin kan opprette brukere.";
      melding.classList.add("feil");
      return;
    }

    const navn = document.getElementById("ansattNavn")
      .value
      .trim();

    const email = document.getElementById("ansattEpost")
      .value
      .trim()
      .toLowerCase();

    const mobil = document.getElementById("ansattMobil")
      .value
      .trim();

    const passord = document.getElementById("ansattPassord")
      .value
      .trim();

    const er_admin =
      document.getElementById("ansattErAdmin")?.checked || false;

    if (!navn || !email || !passord) {
      melding.textContent =
        "Navn, e-post og passord må fylles ut.";
      melding.classList.add("feil");
      return;
    }

    if (passord.length < 6) {
      melding.textContent =
        "Passord må være minst 6 tegn.";
      melding.classList.add("feil");
      return;
    }

    const { data: signupData, error: signupError } =
      await supabaseClient.auth.signUp({
        email: email,
        password: passord
      });

    console.log("SIGNUP:", signupData);
    console.log("SIGNUP ERROR:", signupError);

    if (signupError) {
      melding.textContent =
        "Kunne ikke lage bruker: " +
        signupError.message;

      melding.classList.add("feil");
      return;
    }

    const authUserId =
      signupData?.user?.id || null;

    const ansatt = {
      id: authUserId,
      navn: navn,
      epost: email,
      mobil: mobil,
      er_admin: er_admin
    };

    const { error: dbError } =
      await supabaseClient
        .from("ansatte")
        .insert(ansatt);

    if (dbError) {

      console.error("DB ERROR:", dbError);

      melding.textContent =
        "Bruker laget i auth, men ikke i ansatte-tabell: " +
        dbError.message;

      melding.classList.add("feil");
      return;
    }

    document.getElementById("ansattNavn").value = "";
    document.getElementById("ansattEpost").value = "";
    document.getElementById("ansattMobil").value = "";
    document.getElementById("ansattPassord").value = "";

    const adminCheck =
      document.getElementById("ansattErAdmin");

    if (adminCheck) {
      adminCheck.checked = false;
    }

    melding.textContent =
      "Bruker opprettet.";

    melding.classList.add("ok");

    await lastAnsatte();

  } catch (err) {

    console.error(err);

    melding.textContent =
      "Uventet feil ved opprettelse av bruker.";

    melding.classList.add("feil");
  }
}

function redigerAnsatt(id) {

  const a = ansatte.find(x =>
    String(x.id) === String(id)
  );

  if (!a) return;

  document.getElementById("ansattId").value =
    a.id || "";

  document.getElementById("ansattNavn").value =
    a.navn || "";

  document.getElementById("ansattEpost").value =
    a.epost || "";

  document.getElementById("ansattMobil").value =
    a.mobil || "";

  const adminCheck =
    document.getElementById("ansattErAdmin");

  if (adminCheck) {
    adminCheck.checked = !!a.er_admin;
  }
}

async function slettAnsatt(id) {

  if (!confirm("Slette ansatt?")) {
    return;
  }

  const { error } = await supabaseClient
    .from("ansatte")
    .delete()
    .eq("id", id);

  if (error) {
    console.error(error);

    settMelding(
      "ansattMelding",
      "Feil ved sletting: " + error.message
    );

    return;
  }

  await lastAnsatte();

  settMelding(
    "ansattMelding",
    "Ansatt slettet.",
    true
  );
}

window.opprettBruker = opprettBruker;
window.redigerAnsatt = redigerAnsatt;
window.slettAnsatt = slettAnsatt;