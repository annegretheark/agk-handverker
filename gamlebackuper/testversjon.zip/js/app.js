console.log("NY app.js er lastet");

function el(id) {
  return document.getElementById(id);
}

function settMelding(id, tekst, ok = false) {
  const felt = el(id);
  if (!felt) return;
  felt.textContent = tekst || "";
  felt.className = "melding " + (ok ? "ok" : "feil");
}

function koble(id, event, funksjon) {
  const element = el(id);

  if (!element) {
    console.warn("Fant ikke element:", id);
    return;
  }

  if (typeof funksjon !== "function") {
    console.warn("Fant ikke funksjon for:", id);
    return;
  }

  element.addEventListener(event, funksjon);
}

function tryggFunksjon(navn) {
  return typeof window[navn] === "function" ? window[navn] : undefined;
}

function oppdaterAdminVisning() {
  const erAdmin = window.erAdmin === true;

  [
    "visAnsattKnapp",
    "visFirmaKnapp",
    "fakturaAdminKnapper",
    "kreditnotaKnapp",
    "testKnapp"
  ].forEach(id => {
    const element = el(id);
    if (element) {
      element.classList.toggle("skjult", !erAdmin);
    }
  });
}

function settAdminFraBruker() {
  window.erAdmin = false;

  const bruker = window.innloggetBruker;

  if (
    bruker &&
    String(bruker.email || "").toLowerCase() === "greknuts@online.no"
  ) {
    window.erAdmin = true;
  }

  oppdaterAdminVisning();
}

function visLogin() {
  const loginBoks = el("loginBoks");
  const appBoks = el("appBoks");
  const brukerInfo = el("brukerInfo");

  if (loginBoks) loginBoks.classList.remove("skjult");
  if (appBoks) appBoks.classList.add("skjult");
  if (brukerInfo) brukerInfo.textContent = "";

  window.innloggetBruker = null;
  window.erAdmin = false;
  oppdaterAdminVisning();
}

function visApp() {
  const loginBoks = el("loginBoks");
  const appBoks = el("appBoks");
  const brukerInfo = el("brukerInfo");

  if (loginBoks) loginBoks.classList.add("skjult");
  if (appBoks) appBoks.classList.remove("skjult");

  if (brukerInfo && window.innloggetBruker) {
    brukerInfo.textContent = window.innloggetBruker.email || "";
  }

  settAdminFraBruker();
}

function visSide(sideId) {
  [
    "timerSide",
    "kunderSide",
    "kundeSide",
    "ansatteSide",
    "ansattSide",
    "firmaSide",
    "testSide"
  ].forEach(id => {
    const side = el(id);
    if (side) side.classList.add("skjult");
  });

  const valgtSide = el(sideId);
  if (valgtSide) valgtSide.classList.remove("skjult");
}

function visTimerSide() {
  visSide("timerSide");
}

function visKundeSide() {
  if (el("kunderSide")) {
    visSide("kunderSide");
  } else {
    visSide("kundeSide");
  }
}

function visAnsattSide() {
  if (window.erAdmin !== true) {
    alert("Bare admin kan åpne ansatte.");
    return;
  }

  if (el("ansatteSide")) {
    visSide("ansatteSide");
  } else {
    visSide("ansattSide");
  }
}

function visFirmaSide() {
  if (window.erAdmin !== true) {
    alert("Bare admin kan åpne firma.");
    return;
  }

  visSide("firmaSide");
}

async function loggUt() {
  if (window.supabaseClient) {
    await window.supabaseClient.auth.signOut();
  }

  visLogin();
  settMelding("loginMelding", "Du er logget ut.", true);
}

function kobleKnapper() {
  koble("loginKnapp", "click", tryggFunksjon("loggInn"));
  koble("glemtPassordKnapp", "click", tryggFunksjon("glemtPassord"));
  koble("lagreNyttPassordKnapp", "click", tryggFunksjon("lagreNyttPassord"));
  koble("tilbakeTilLoginKnapp", "click", tryggFunksjon("visLogin"));
  koble("loggUtKnapp", "click", tryggFunksjon("loggUt"));

  koble("visTimerKnapp", "click", tryggFunksjon("visTimerSide"));
  koble("visKundeKnapp", "click", tryggFunksjon("visKundeSide"));
  koble("visAnsattKnapp", "click", tryggFunksjon("visAnsattSide"));
  koble("visFirmaKnapp", "click", tryggFunksjon("visFirmaSide"));

  koble("leggTilKundeKnapp", "click", tryggFunksjon("lagreKunde"));
  koble("tilbakeTilTimerKnapp", "click", tryggFunksjon("visTimerSide"));

  koble("leggTilTrekkKnapp", "click", tryggFunksjon("leggTilTrekk"));
  koble("lagreAnsattKnapp", "click", tryggFunksjon("lagreAnsatt"));
  koble("tilbakeFraAnsattKnapp", "click", tryggFunksjon("visTimerSide"));

  koble("lagreFirmaKnapp", "click", tryggFunksjon("lagreFirma"));
  koble("firmaLogo", "change", tryggFunksjon("lastInnLogo"));
  koble("tilbakeFraFirmaKnapp", "click", tryggFunksjon("visTimerSide"));

  koble("lagreTimerKnapp", "click", tryggFunksjon("lagreTimer"));
  koble("excelKnapp", "click", tryggFunksjon("eksporterMvaRegneark"));
  koble("pdfKnapp", "click", tryggFunksjon("lagFakturaPdf"));
  koble("backupKnapp", "click", tryggFunksjon("backup"));
  koble("kreditnotaKnapp", "click", tryggFunksjon("visKreditnotaPrompt"));

  const importFil = el("importFil");
  if (importFil && typeof window.importerBackup === "function") {
    importFil.addEventListener("change", window.importerBackup);
  }

  const kundeValg = el("kundeValg");
  if (kundeValg && typeof window.visKundeNavn === "function") {
    kundeValg.addEventListener("change", window.visKundeNavn);
  }

  const startTidFelt = el("startTid");
  if (startTidFelt) {
    startTidFelt.addEventListener("change", () => {
      const sluttTid = el("sluttTid");
      if (sluttTid) sluttTid.focus();
    });
  }
}

async function stressTest() {
  if (!window.supabaseClient) {
    alert("Supabase er ikke lastet.");
    return;
  }

  const behold = "greknuts@online.no";

  const testEposter = [
    "kurs@jobbsmartkurs.no",
    "lykke@jobbsmartkurs.no",
    "rotern@jobbsmartkurs.no",
    "taxi@jobbsmartkurs.no",
    "tulling@jobbsmartkurs.no",
    "annegrethek@hotmail.com"
  ];

  if (!confirm("Kjøre stresstest? Dette sletter testdata, men beholder greknuts.")) {
    return;
  }

  console.log("Starter stresstest...");

  await window.supabaseClient
    .from("timer")
    .delete()
    .neq("id", "00000000-0000-0000-0000-000000000000");

  await window.supabaseClient
    .from("ansatte")
    .delete()
    .neq("epost", behold);

  console.log("Gamle testdata slettet");

  for (const epost of testEposter) {
    if (typeof window.opprettAuthBrukerHvisMangler === "function") {
      await window.opprettAuthBrukerHvisMangler(epost, "testMelding");
    }

    await window.supabaseClient.from("ansatte").insert({
      navn: epost.split("@")[0],
      epost: epost,
      timepris: 1100,
      rolle: "bruker",
      aktiv: true
    });
  }

  console.log("Ansatte opprettet");

  for (let i = 1; i <= 10; i++) {
    await window.supabaseClient.from("kunder").insert({
      navn: "TEST_KUNDE_" + i,
      epost: "kunde" + i + "@test.no"
    });
  }

  console.log("Kunder opprettet");

  const { data: ansatte } = await window.supabaseClient.from("ansatte").select("*");
  const { data: kunder } = await window.supabaseClient.from("kunder").select("*");

  for (let i = 0; i < 200; i++) {
    const ansatt = ansatte[Math.floor(Math.random() * ansatte.length)];
    const kunde = kunder[Math.floor(Math.random() * kunder.length)];

    await window.supabaseClient.from("timer").insert({
      ansatt_id: ansatt.id,
      kunde_id: kunde.id,
      dato: "2026-05-01",
      timer: Math.round((Math.random() * 8) * 100) / 100,
      beskrivelse: "TEST",
      kommentar: "STRESSTEST",
      fakturerbar: true,
      timepris: 1100
    });
  }

  console.log("Timer opprettet");

  if (typeof window.lastKunder === "function") await window.lastKunder();
  if (typeof window.lastTimer === "function") await window.lastTimer();

  alert("Stresstest ferdig 🚀");
}

async function startApp() {
  console.log("Starter app");

  if (!window.supabaseClient) {
    settMelding("loginMelding", "FEIL: config.js mangler.");
    return;
  }

  kobleKnapper();

  window.erAdmin = false;
  oppdaterAdminVisning();

  if (window.supabaseClient.auth) {
    window.supabaseClient.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" && typeof window.visNyttPassord === "function") {
        window.visNyttPassord();
      }
    });
  }

  if (typeof window.blankTimer === "function") {
    window.blankTimer();
  }

  // TESTMILJØ: alltid start på login, ikke automatisk inn som greknuts
  await window.supabaseClient.auth.signOut();

  visLogin();
}

window.el = el;
window.settMelding = settMelding;
window.visLogin = visLogin;
window.visApp = visApp;
window.visSide = visSide;
window.visTimerSide = visTimerSide;
window.visKundeSide = visKundeSide;
window.visAnsattSide = visAnsattSide;
window.visFirmaSide = visFirmaSide;
window.loggUt = loggUt;
window.stressTest = stressTest;
window.oppdaterAdminVisning = oppdaterAdminVisning;
window.settAdminFraBruker = settAdminFraBruker;
window.addEventListener("load", startApp);
koble("opprettBrukerKnapp", "click", tryggFunksjon("opprettBruker"));