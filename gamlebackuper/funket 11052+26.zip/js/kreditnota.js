const KREDITNOTA_MVA_SATS = 0.25;

function kreditnotaFormatBelop(verdi) {
  return Number(verdi || 0).toFixed(2).replace('.', ',');
}

function kreditnotaTryggFilnavn(tekst) {
  return String(tekst || 'kreditnota')
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 80);
}

function kreditnotaDatoISO(dato) {
  return new Date(dato).toISOString().slice(0, 10);
}

function kreditnotaMaaned() {
  const felt = document.getElementById('fakturaMaaned') || document.getElementById('maaned');
  return felt && felt.value ? felt.value : new Date().toISOString().slice(0, 7);
}

function kreditnotaValgtKunde() {
  if (typeof hentValgtKunde === 'function') return hentValgtKunde();

  const kundeId = document.getElementById('kundeValg')?.value || document.getElementById('fakturaKunde')?.value || '';
  if (!kundeId) return null;

  return (window.kunder || []).find(k => String(k.id) === String(kundeId)) || null;
}

function kreditnotaErSammeKunde(time, kunde) {
  if (!kunde) return true;
  if (typeof erSammeKunde === 'function') return erSammeKunde(time, kunde);

  const tidKunde = time.kunde_id || time.kundeId || time.kundenr || time.kunde_nr || time.kundeNavn || time.kunde_navn;
  return String(tidKunde || '') === String(kunde.id || kunde.kundenr || kunde.navn || '');
}

function kreditnotaSummer(timerListe) {
  return (timerListe || []).reduce((acc, t) => {
    let eks = 0;

    if (typeof beregnMvaLinje === 'function') {
      eks = Number(beregnMvaLinje(t).sumEksMva || 0);
    } else if (t.sum !== undefined && t.sum !== null && Number(t.sum) > 0) {
      eks = Number(t.sum);
    } else {
      eks = Number(t.timer || 0) * Number(t.timepris || 0);
    }

    acc.eks += eks;
    acc.mva += eks * KREDITNOTA_MVA_SATS;
    acc.inkl += eks * (1 + KREDITNOTA_MVA_SATS);
    return acc;
  }, { eks: 0, mva: 0, inkl: 0 });
}

function kreditnotaKundeNavn(kunde, time) {
  if (typeof hentKundeNavn === 'function') return hentKundeNavn(kunde, time);
  return kunde?.navn || time?.kunde_navn || time?.kundeNavn || 'Kunde';
}

function kreditnotaKundeNr(kunde, time) {
  if (typeof hentKundeNr === 'function') return hentKundeNr(kunde, time);
  return kunde?.kundenr || time?.kunde_nr || time?.kundeNr || '';
}

function lagKreditnotaMvaCsv(fakturanr, kunde, timerListe, maaned) {
  const summer = kreditnotaSummer(timerListe);
  const kolonner = ['type', 'fakturanr', 'kunde_nr', 'kunde_navn', 'dato', 'sum_eks_mva', 'mva_25', 'sum_inkl_mva'];
  const rad = [
    'KREDITNOTA',
    fakturanr,
    kreditnotaKundeNr(kunde, timerListe[0]),
    kreditnotaKundeNavn(kunde, timerListe[0]),
    maaned,
    kreditnotaFormatBelop(-summer.eks),
    kreditnotaFormatBelop(-summer.mva),
    kreditnotaFormatBelop(-summer.inkl)
  ];

  const csvVerdi = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const csv = [kolonner, rad].map(r => r.map(csvVerdi).join(';')).join('\r\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');

  a.href = url;
  a.download = `kreditnota_mva_${kreditnotaTryggFilnavn(fakturanr)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

async function lagKreditnota(fakturanr) {
  const melding = document.getElementById('skjemaMelding') || document.getElementById('timerMelding');
  const jspdfObj = window.jspdf;

  if (!jspdfObj || !jspdfObj.jsPDF) {
    alert('PDF-biblioteket er ikke lastet.');
    return;
  }

  const maaned = kreditnotaMaaned();
  const kunde = kreditnotaValgtKunde();

  const timerListe = (window.timer || [])
    .filter(t => String(t.dato || '').slice(0, 7) === maaned)
    .filter(t => t.fakturerbar !== false)
    .filter(t => t.fakturert === true || t.fakturert === 'true' || t.faktura_nr || t.fakturanr)
    .filter(t => kreditnotaErSammeKunde(t, kunde));

  if (!timerListe.length) {
    alert('Fant ingen fakturerte timer for valgt måned/kunde. Velg samme måned og kunde som fakturaen gjelder.');
    return;
  }

  const kreditKey = 'kreditnota_laget_' + String(fakturanr || '').trim().toLowerCase();
  const erKopi = localStorage.getItem(kreditKey) === 'true';
  const summer = kreditnotaSummer(timerListe);
  const firma = typeof hentFirmaData === 'function' ? await hentFirmaData() : {};
  const doc = new jspdfObj.jsPDF();
  let y = 15;

  if (typeof leggTilLogo === 'function') leggTilLogo(doc, firma);

  doc.setFontSize(18);
  doc.text(erKopi ? 'Kreditnota - KOPI' : 'Kreditnota', 14, y);
  y += 10;

  doc.setFontSize(10);
  doc.text(firma.navn || '', 14, y); y += 5;
  doc.text(firma.adresse || '', 14, y); y += 5;
  if (firma.orgnr) { doc.text('Org.nr: ' + firma.orgnr, 14, y); y += 5; }
  if (firma.mva_nr || firma.mvanr) { doc.text('MVA-nr: ' + (firma.mva_nr || firma.mvanr), 14, y); y += 5; }
  if (firma.kontonr || firma.konto_nr) { doc.text('Konto: ' + (firma.kontonr || firma.konto_nr), 14, y); y += 5; }

  y += 5;
  doc.setFontSize(12);
  doc.text('Krediterer faktura: ' + fakturanr, 14, y); y += 7;
  doc.setFontSize(10);
  doc.text('Kunde: ' + kreditnotaKundeNavn(kunde, timerListe[0]), 14, y); y += 5;
  doc.text('Periode: ' + maaned, 14, y); y += 5;
  doc.text('Dato: ' + kreditnotaDatoISO(new Date()), 14, y); y += 10;

  doc.text('Sum eks mva:', 120, y);
  doc.text(kreditnotaFormatBelop(-summer.eks), 180, y); y += 6;
  doc.text('MVA 25%:', 120, y);
  doc.text(kreditnotaFormatBelop(-summer.mva), 180, y); y += 6;
  doc.setFontSize(12);
  doc.text('Sum inkl mva:', 120, y);
  doc.text(kreditnotaFormatBelop(-summer.inkl), 180, y); y += 10;

  doc.setFontSize(9);
  doc.text('Kreditnotaen reverserer fakturerte timer for valgt måned/kunde.', 14, y);

  doc.save(`kreditnota_${kreditnotaTryggFilnavn(fakturanr)}${erKopi ? '_KOPI' : ''}.pdf`);

  if (!erKopi) {
    lagKreditnotaMvaCsv(fakturanr, kunde, timerListe, maaned);
    localStorage.setItem(kreditKey, 'true');
  }

  if (melding) {
    melding.textContent = erKopi
      ? 'Kreditnota-kopi er laget. Ingen ny MVA-linje ble laget.'
      : 'Kreditnota er laget, og negativ MVA-linje er eksportert én gang.';
  }
}

window.lagKreditnota = lagKreditnota;
