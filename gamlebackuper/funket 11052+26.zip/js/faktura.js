const MVA_SATS = 0.25;

function formatBelop(verdi) {
  return Number(verdi || 0).toLocaleString("no-NO", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function tryggFilnavn(tekst) {
  return String(tekst || "faktura")
    .toLowerCase()
    .replace(/[æ]/g, "ae")
    .replace(/[ø]/g, "o")
    .replace(/[å]/g, "a")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function formatDatoISO(dato) {
  return dato.toISOString().slice(0, 10);
}

function leggTilDager(dato, dager) {
  const nyDato = new Date(dato);
  nyDato.setDate(nyDato.getDate() + dager);
  return nyDato;
}

function hentValgtMaaned() {
  const datoFelt = document.getElementById("dato");
  const dato = datoFelt && datoFelt.value ? datoFelt.value : new Date().toISOString().slice(0, 10);
  return dato.slice(0, 7);
}

function hentValgtKunde() {
  const kundeValg = document.getElementById("kundeValg");

  if (!kundeValg || !kundeValg.value) {
    return null;
  }

  const valgtId = String(kundeValg.value);

  return (window.kunder || []).find(k =>
    String(k.id || "") === valgtId ||
    String(k.kundenr || "") === valgtId
  ) || null;
}

async function hentFirmaData() {
  try {
    const { data, error } =
      await supabaseClient
        .from("firma")
        .select("*")
        .limit(1)
        .maybeSingle();

    if (error) console.warn(error);

    return data || {};
  } catch (e) {
    console.warn(e);
    return {};
  }
}

function hentKundeNr(kunde, time) {
  return String(
    kunde?.kundenr ||
    kunde?.kunde_nr ||
    kunde?.id ||
    time?.kunde_nr ||
    time?.kundeNr ||
    time?.kunde_id ||
    ""
  );
}

function hentKundeNavn(kunde, time) {
  return String(
    kunde?.navn ||
    time?.kunde_navn ||
    time?.kundeNavn ||
    time?.kunde ||
    "Kunde"
  );
}

function finnKundeForTime(time) {
  const kunder = window.kunder || [];

  return kunder.find(k =>
    String(k.id || "") === String(time.kunde_id || "") ||
    String(k.kundenr || "") === String(time.kunde_nr || time.kundeNr || "") ||
    String(k.navn || "").toLowerCase() ===
    String(time.kunde_navn || time.kundeNavn || time.kunde || "").toLowerCase()
  ) || null;
}

function erSammeKunde(time, kunde) {
  if (!kunde) return true;

  return (
    String(time.kunde_id || "") === String(kunde.id || "") ||
    String(time.kunde_nr || time.kundeNr || "") === String(kunde.kundenr || kunde.id || "") ||
    String(time.kunde_navn || time.kundeNavn || time.kunde || "").toLowerCase() ===
    String(kunde.navn || "").toLowerCase()
  );
}

function erAlleredeFakturert(time) {
  return (
    time.fakturerbar === false ||
    time.fakturert === true ||
    time.faktura_id ||
    time.fakturanr ||
    time.fakturert_dato
  );
}

function beregnSumEksMvaForTime(time) {
  if (
    time.sum !== undefined &&
    time.sum !== null &&
    Number(time.sum) > 0
  ) {
    return Number(time.sum);
  }

  return Number(time.timer || 0) * Number(time.timepris || 0);
}

function beregnMvaLinje(time) {
  const sumEksMva = beregnSumEksMvaForTime(time);
  const mva = sumEksMva * MVA_SATS;
  const sumInkMva = sumEksMva + mva;

  return {
    sumEksMva,
    mva,
    sumInkMva
  };
}

function summerTimerMedMva(timerListe) {
  return timerListe.reduce(
    (acc, t) => {
      const linje = beregnMvaLinje(t);

      acc.sumEksMva += linje.sumEksMva;
      acc.mva += linje.mva;
      acc.sumInkMva += linje.sumInkMva;

      return acc;
    },
    {
      sumEksMva: 0,
      mva: 0,
      sumInkMva: 0
    }
  );
}

function grupperTimerPerKunde(timerListe) {
  const grupper = new Map();

  timerListe.forEach(t => {
    const kunde =
      finnKundeForTime(t) || {
        id: t.kunde_id || t.kunde_nr || t.kunde_navn || "kunde",
        kundenr: t.kunde_nr || t.kunde_id || "",
        navn: t.kunde_navn || t.kunde || "Kunde",
        adresse: "",
        postadresse: ""
      };

    const key = String(kunde.id || kunde.kundenr || kunde.navn || "kunde");

    if (!grupper.has(key)) {
      grupper.set(key, {
        kunde,
        timer: []
      });
    }

    grupper.get(key).timer.push(t);
  });

  return Array.from(grupper.values());
}

function hentLogoFraImgElement() {
  try {
    const img = document.getElementById("fakturaLogoBilde");

    if (!img || !img.complete || !img.naturalWidth) {
      return null;
    }

    const canvas = document.createElement("canvas");
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);

    return {
      data: canvas.toDataURL("image/png"),
      width: img.naturalWidth,
      height: img.naturalHeight
    };
  } catch (e) {
    console.warn("Kunne ikke hente logo fra img:", e);
    return null;
  }
}

async function hentLogoFraUrl(url) {
  try {
    const response = await fetch(url, { cache: "no-store" });

    if (!response.ok) {
      return null;
    }

    const blob = await response.blob();

    const data = await new Promise(resolve => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });

    return {
      data,
      width: 0,
      height: 0
    };
  } catch (e) {
    console.warn("Kunne ikke hente logo fra url:", url, e);
    return null;
  }
}

async function leggTilLogo(doc, firma) {
  try {
    let logo = hentLogoFraImgElement();

    if (!logo) {
      const sti = window.location.pathname.split("/").slice(0, -1).join("/");
      const base = window.location.origin + sti;

      const logoKandidater = [
        firma.logo,
        "bilder/logo.png",
        "./bilder/logo.png",
        base + "/bilder/logo.png",
        window.location.origin + "/NyTimerdelt/bilder/logo.png",
        "/NyTimerdelt/bilder/logo.png",
        "/bilder/logo.png"
      ].filter(Boolean);

      for (const kandidat of logoKandidater) {
        logo = await hentLogoFraUrl(kandidat);
        if (logo) break;
      }
    }

    if (!logo || !logo.data) {
      console.warn("Ingen logo funnet. Faktura lages uten logo.");
      return false;
    }

    let bredde = 28;
    let hoyde = 14;

    try {
      const props = doc.getImageProperties(logo.data);
      const forhold = props.width / props.height;

      bredde = 28;
      hoyde = bredde / forhold;

      if (hoyde > 14) {
        hoyde = 14;
        bredde = hoyde * forhold;
      }
    } catch (e) {
      console.warn("Kunne ikke lese logostørrelse, bruker standard.");
    }

    doc.addImage(
  logo.data,
  "PNG",
  14,
  10,
  45,
  20
);

    return true;
  } catch (e) {
    console.warn("Kunne ikke legge logo på faktura:", e);
    return false;
  }
}

async function sperrFakturerteTimer(timerListe, fakturanr) {
  const ider =
    timerListe
      .map(t => t.id)
      .filter(Boolean);

  timerListe.forEach(t => {
    t.fakturerbar = false;
    t.fakturert = true;
    t.fakturanr = fakturanr;
    t.fakturert_dato = new Date().toISOString();
  });

  if (!ider.length) {
    return true;
  }

  try {
    const { error } =
      await supabaseClient
        .from("timer")
        .update({
          fakturerbar: false
        })
        .in("id", ider);

    if (error) {
      console.warn("Kunne ikke sperre fakturerte timer:", error);
      return false;
    }

    return true;
  } catch (e) {
    console.warn("Kunne ikke sperre fakturerte timer:", e);
    return false;
  }
}

async function lagEnFakturaPdf(
  kunde,
  fakturaTimer,
  maaned,
  firma,
  erKopi = false
) {
  const jspdfObj = window.jspdf;

  if (!jspdfObj || !jspdfObj.jsPDF) {
    alert("PDF-biblioteket er ikke lastet.");
    return;
  }

  const doc = new jspdfObj.jsPDF();

  const summer = summerTimerMedMva(fakturaTimer);
  const fakturaDato = new Date();
  const forfallsDato = leggTilDager(fakturaDato, 14);

  const fakturanr =
    "F-" +
    formatDatoISO(fakturaDato).replaceAll("-", "") +
    "-" +
    Math.floor(Math.random() * 9000 + 1000);

  await leggTilLogo(doc, firma);

  let y = 20;

  doc.setFontSize(20);
  doc.text("FAKTURA", 14, y);

  if (erKopi) {
    doc.setFontSize(14);
    doc.text("KOPI", 170, y);
  }

  y += 20;

  doc.setFontSize(11);

  doc.text(firma.navn || "", 14, y);
  y += 5;

  doc.text(firma.adresse || "", 14, y);
  y += 5;

  doc.text(firma.postadresse || "", 14, y);

  let høyreY = 40;

  doc.setFontSize(10);

  doc.text("Forfallsdato", 140, høyreY);
  doc.text(formatDatoISO(forfallsDato), 175, høyreY);

  høyreY += 6;

  doc.text("Kontonr", 140, høyreY);
  doc.text(firma.kontonr || "", 175, høyreY);

  høyreY += 6;

  doc.text("Fakturanr", 140, høyreY);
  doc.text(fakturanr, 175, høyreY);

  høyreY += 6;

  doc.text("Dato", 140, høyreY);
  doc.text(formatDatoISO(fakturaDato), 175, høyreY);

  høyreY += 6;

  doc.text("Kundenr", 140, høyreY);
  doc.text(hentKundeNr(kunde, fakturaTimer[0]), 175, høyreY);

  y += 20;

  doc.setFontSize(12);
  doc.text(hentKundeNavn(kunde, fakturaTimer[0]), 14, y);

  y += 6;

  doc.setFontSize(10);

  if (kunde.adresse) {
    doc.text(kunde.adresse, 14, y);
    y += 5;
  }

  if (kunde.postadresse) {
    doc.text(kunde.postadresse, 14, y);
    y += 5;
  }

  y += 10;

  doc.text("Dato", 14, y);
  doc.text("Beskrivelse", 45, y);
  doc.text("Timer", 120, y);
  doc.text("Eks mva", 145, y);
  doc.text("MVA", 170, y);

  y += 4;

  doc.line(14, y, 195, y);

  y += 7;

  fakturaTimer.forEach(t => {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }

    const linje = beregnMvaLinje(t);
    const tekst = String(t.beskrivelse || t.kommentar || "Timer").slice(0, 40);

    doc.text(String(t.dato || ""), 14, y);
    doc.text(tekst, 45, y);
    doc.text(String(t.timer || 0), 120, y);
    doc.text(formatBelop(linje.sumEksMva), 145, y);
    doc.text(formatBelop(linje.mva), 170, y);

    y += 6;
  });

  y += 4;

  doc.line(120, y, 195, y);

  y += 8;

  doc.setFontSize(11);

  doc.text("Sum eks mva:", 130, y);
  doc.text(formatBelop(summer.sumEksMva) + " kr", 170, y);

  y += 6;

  doc.text("MVA 25%:", 130, y);
  doc.text(formatBelop(summer.mva) + " kr", 170, y);

  y += 6;

  doc.setFontSize(12);

  doc.text("Sum inkl mva:", 130, y);
  doc.text(formatBelop(summer.sumInkMva) + " kr", 170, y);

  doc.setFontSize(9);

  doc.text(firma.navn || "", 14, 285);
  doc.text(firma.adresse || "", 70, 285);
  doc.text(firma.postadresse || "", 120, 285);
  doc.text("MVA: " + (firma.mva_nr || ""), 170, 285);

  const filnavn =
    `${tryggFilnavn(hentKundeNavn(kunde, fakturaTimer[0]))}_${maaned}${erKopi ? "_KOPI" : ""}.pdf`;

  doc.save(filnavn);

  if (!erKopi) {
    await sperrFakturerteTimer(fakturaTimer, fakturanr);
  }
}

async function lagFakturaPdf() {
  const melding = document.getElementById("timerMelding");

  try {
    const maaned = hentValgtMaaned();
    const firma = await hentFirmaData();
    const valgtKunde = hentValgtKunde();

    const timerForMaaned =
      (window.timer || [])
        .filter(t => !erAlleredeFakturert(t))
        .filter(t => String(t.dato || "").slice(0, 7) === maaned)
        .filter(t => erSammeKunde(t, valgtKunde));

    if (!timerForMaaned.length) {
      if (melding) {
        melding.textContent =
          "Fant ingen fakturerbare timer. De kan allerede være fakturert.";
      }

      return;
    }

    const grupper = grupperTimerPerKunde(timerForMaaned);

    for (const gruppe of grupper) {
      await lagEnFakturaPdf(
        gruppe.kunde,
        gruppe.timer,
        maaned,
        firma,
        false
      );
    }

    if (melding) {
      melding.textContent =
        "Faktura PDF laget. Timene er sperret mot ny fakturering.";
    }
  } catch (e) {
    console.error("Faktura feilet:", e);

    if (melding) {
      melding.textContent =
        "Faktura feilet. Se Console for feilmelding.";
    }

    alert("Faktura feilet. Se Console for feilmelding.");
  }
}

window.lagFakturaPdf = lagFakturaPdf;

document.addEventListener("DOMContentLoaded", function () {
  const pdfKnapp = document.getElementById("pdfKnapp");

  if (pdfKnapp) {
    pdfKnapp.onclick = function () {
      lagFakturaPdf();
    };
  } else {
    console.warn("Fant ikke pdfKnapp");
  }
});