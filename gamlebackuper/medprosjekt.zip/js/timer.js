console.log("NY timer.js er lastet");

const MAKS_TIMER_PER_DAG = 24;
const MAKS_TIMER_PER_MANED = 300;

function hentTimerMelding() {
  return document.getElementById("timerMelding") || document.getElementById("skjemaMelding");
}

function tallFraFelt(id) {
  const felt = document.getElementById(id);
  if (!felt) return 0;
  const verdi = String(felt.value || "").replace(",", ".").trim();
  return verdi === "" ? 0 : Number(verdi);
}

function tekstFraFelt(id) {
  const felt = document.getElementById(id);
  return felt ? String(felt.value || "").trim() : "";
}

function settFeltHvisFinnes(id, verdi) {
  const felt = document.getElementById(id);
  if (felt) felt.value = verdi;
}

function settDagensDato() {
  const dato = document.getElementById("dato");
  if (dato && !dato.value) {
    dato.value = new Date().toISOString().split("T")[0];
  }
}

function hentManedStart(dato) {
  return dato.substring(0, 7) + "-01";
}

function hentNesteManedStart(dato) {
  const deler = dato.split("-");
  const aar = Number(deler[0]);
  const maned = Number(deler[1]);

  let nesteAar = aar;
  let nesteManed = maned + 1;

  if (nesteManed > 12) {
    nesteManed = 1;
    nesteAar++;
  }

  return `${nesteAar}-${String(nesteManed).padStart(2, "0")}-01`;
}

function adminVilOverstyre(tekst) {
  if (!erAdmin) return false;

  return confirm(
    tekst +
    "\n\nDu er admin. Vil du overstyre og lagre likevel?"
  );
}

async function lastTimer() {
  let query = supabaseClient
    .from("timer")
    .select("*")
    .order("dato", { ascending: false });

  if (!erAdmin && window.innloggetAnsattId) {
    query = query.eq("ansatt_id", window.innloggetAnsattId);
  }

  const { data, error } = await query;

  if (error) {
    const melding = hentTimerMelding();
    if (melding) melding.textContent = "Feil ved henting av timer: " + error.message;
    console.error("Feil ved henting av timer:", error);
    return;
  }

  window.timer = data || [];
  tegnTimer();
}

async function sjekkTimerGrenser(ansattId, dato, nyeTimer) {
  const melding = hentTimerMelding();

  const { data: dagTimer, error: dagFeil } = await supabaseClient
    .from("timer")
    .select("timer")
    .eq("ansatt_id", ansattId)
    .eq("dato", dato);

  if (dagFeil) {
    if (melding) melding.textContent = "Feil ved sjekk av dagstimer: " + dagFeil.message;
    return false;
  }

  const sumDag =
    (dagTimer || []).reduce((sum, rad) => sum + tallFraVerdi(rad.timer), 0) +
    nyeTimer;

  if (sumDag > MAKS_TIMER_PER_DAG) {
    const tekst =
      `Det blir ${round(sumDag)} timer denne dagen. Maks er ${MAKS_TIMER_PER_DAG} timer.`;

    if (!adminVilOverstyre(tekst)) {
      if (melding) melding.textContent = tekst;
      return false;
    }
  }

  const manedStart = hentManedStart(dato);
  const nesteManedStart = hentNesteManedStart(dato);

  const { data: manedTimer, error: manedFeil } = await supabaseClient
    .from("timer")
    .select("timer")
    .eq("ansatt_id", ansattId)
    .gte("dato", manedStart)
    .lt("dato", nesteManedStart);

  if (manedFeil) {
    if (melding) melding.textContent = "Feil ved sjekk av månedstimer: " + manedFeil.message;
    return false;
  }

  const sumManed =
    (manedTimer || []).reduce((sum, rad) => sum + tallFraVerdi(rad.timer), 0) +
    nyeTimer;

  if (sumManed > MAKS_TIMER_PER_MANED) {
    const tekst =
      `Det blir ${round(sumManed)} timer denne måneden. Maks er ${MAKS_TIMER_PER_MANED} timer.`;

    if (!adminVilOverstyre(tekst)) {
      if (melding) melding.textContent = tekst;
      return false;
    }
  }

  return true;
}

function tallFraVerdi(verdi) {
  if (verdi === null || verdi === undefined || verdi === "") return 0;
  const tall = Number(String(verdi).replace(",", "."));
  return Number.isFinite(tall) ? tall : 0;
}

async function lagreTimer() {
  const ansattId = window.innloggetAnsattId || "";
  const melding = hentTimerMelding();

  if (melding) melding.textContent = "";

  const kundeValg = document.getElementById("kundeValg");

  if (!kundeValg) {
    if (melding) melding.textContent = "Fant ikke kundevalg i skjemaet.";
    return;
  }

  const valgtKunde = typeof finnKundeFraValg === "function"
    ? finnKundeFraValg(kundeValg.value)
    : (window.kunder || []).find(k => String(k.id || "") === String(kundeValg.value));

  const valgtKundeNr = typeof hentKundeNr === "function"
    ? hentKundeNr(valgtKunde)
    : (valgtKunde?.kundenr || valgtKunde?.kunde_nr || "");

  const valgtKundeId = valgtKunde?.id || null;
  const valgtProsjektId = tekstFraFelt("prosjektValg") || null;

  const utgiftType = tekstFraFelt("utgiftType");
  const utgiftBelop = tallFraFelt("utgiftBelop");

  const diett = utgiftType === "diett" ? utgiftBelop : tallFraFelt("diett");
  const parkering = utgiftType === "parkering" ? utgiftBelop : tallFraFelt("parkering");
  const billetter = utgiftType === "billetter" ? utgiftBelop : tallFraFelt("billetter");
  const bompenger = utgiftType === "bompenger" ? utgiftBelop : tallFraFelt("bompenger");
  const ferge = utgiftType === "ferge" ? utgiftBelop : 0;
  const annetUtleggFraNedtrekk = utgiftType === "annet" ? utgiftBelop : 0;

  const andreUtlegg = tallFraFelt("andreUtlegg") + annetUtleggFraNedtrekk + ferge;
  const sumUtlegg = diett + parkering + billetter + bompenger + andreUtlegg;

  const registrering = {
    dato: tekstFraFelt("dato"),
    kundeId: valgtKundeId,
    kundeNr: valgtKundeNr,
    kundeNavn: valgtKunde ? valgtKunde.navn || "" : "",
    prosjektId: valgtProsjektId,
    start: tekstFraFelt("startTid"),
    slutt: tekstFraFelt("sluttTid"),
    timepris: tallFraFelt("timepris"),
    km: tallFraFelt("km"),
    kmPris: tallFraFelt("kmPris"),
    diett,
    parkering,
    billetter,
    bompenger,
    andreUtlegg,
    sumUtlegg,
    andreUtleggBeskrivelse:
      tekstFraFelt("andreUtleggBeskrivelse") ||
      (utgiftType ? `Utgiftstype: ${utgiftType}` : ""),
    fakturerbar: tekstFraFelt("fakturerbar") !== "nei",
    beskrivelse: tekstFraFelt("beskrivelse")
  };

  if (!registrering.dato || !registrering.kundeId || !registrering.start || !registrering.slutt) {
    if (melding) {
      melding.textContent = "Fyll inn dato, kunde, start og slutt.";
    }
    return;
  }

  if (!ansattId) {
    if (melding) melding.textContent = "Fant ikke innlogget ansatt.";
    return;
  }

  const beregning = beregnTimer(
    registrering.start,
    registrering.slutt,
    registrering.timepris
  );

  registrering.timer = beregning.timer;
  registrering.overtid50 = beregning.overtid50;
  registrering.overtid100 = beregning.overtid100;
  registrering.sumTimer = beregning.sumTimer;
  registrering.sumKm = registrering.km * registrering.kmPris;

  if (registrering.timer <= 0) {
    if (melding) melding.textContent = "Timer må være større enn 0.";
    return;
  }

  if (registrering.timer > MAKS_TIMER_PER_DAG) {
    const tekst =
      `Denne registreringen er på ${registrering.timer} timer. Maks er ${MAKS_TIMER_PER_DAG} timer per registrering/dag.`;

    if (!adminVilOverstyre(tekst)) {
      if (melding) melding.textContent = tekst;
      return;
    }
  }

  const grenserOk = await sjekkTimerGrenser(
    ansattId,
    registrering.dato,
    registrering.timer
  );

  if (!grenserOk) return;

  registrering.sum = registrering.fakturerbar
    ? registrering.sumTimer + registrering.sumKm + registrering.sumUtlegg
    : 0;

  const supabaseTimer = {
    ansatt_id: ansattId,
    dato: registrering.dato,
    kunde_id: registrering.kundeId,
    kunde_nr: registrering.kundeNr,
    kunde_navn: registrering.kundeNavn,
    prosjekt_id: registrering.prosjektId,
    start: registrering.start,
    slutt: registrering.slutt,
    timer: registrering.timer,
    overtid50: registrering.overtid50,
    overtid100: registrering.overtid100,
    timepris: registrering.timepris,
    km: registrering.km,
    km_pris: registrering.kmPris,
    sum_timer: registrering.sumTimer,
    sum_km: registrering.sumKm,
    diett: registrering.diett,
    parkering: registrering.parkering,
    billetter: registrering.billetter,
    bompenger: registrering.bompenger,
    andre_utlegg: registrering.andreUtlegg,
    andre_utlegg_beskrivelse: registrering.andreUtleggBeskrivelse,
    sum: registrering.sum,
    fakturerbar: registrering.fakturerbar,
    beskrivelse: registrering.beskrivelse
  };

  const { data: finnesFraFor, error: sjekkFeil } = await supabaseClient
    .from("timer")
    .select("id")
    .eq("ansatt_id", ansattId)
    .eq("kunde_id", registrering.kundeId)
    .eq("dato", registrering.dato)
    .eq("start", registrering.start)
    .limit(1);

  if (sjekkFeil) {
    console.error("Feil ved sjekk av dobbeltregistrering:", sjekkFeil);

    if (melding) {
      melding.textContent =
        "Feil ved sjekk av dobbeltregistrering: " + sjekkFeil.message;
    }

    return;
  }

  if (finnesFraFor && finnesFraFor.length > 0) {
    const tekst =
      "Denne timen er allerede registrert for samme ansatt, kunde, dato og starttid.";

    if (!adminVilOverstyre(tekst)) {
      if (melding) melding.textContent = tekst;
      return;
    }
  }

  const { error } = await supabaseClient
    .from("timer")
    .insert([supabaseTimer]);

  if (error) {
    console.error("Feil ved lagring av timer:", error);
    if (melding) melding.textContent = "Feil ved lagring av timer: " + error.message;
    return;
  }

  await lastTimer();
  nullstillSkjema();

  if (melding) melding.textContent = "Timer er lagret.";
}

function beregnTimer(start, slutt, pris) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = slutt.split(":").map(Number);

  let startMin = sh * 60 + sm;
  let sluttMin = eh * 60 + em;

  if (sluttMin <= startMin) {
    sluttMin += 24 * 60;
  }

  const timerTotalt = (sluttMin - startMin) / 60;
  const sumTimer = timerTotalt * pris;

  return {
    timer: round(timerTotalt),
    overtid50: 0,
    overtid100: 0,
    sumTimer: round(sumTimer)
  };
}

function kundeInfoForTimer(t) {
  const kunde = (window.kunder || []).find(k =>
    String(k.id || "") === String(t.kunde_id || "")
  );

  const kundeNr =
    t.kunde_nr ||
    t.kundeNr ||
    (kunde ? hentKundeNr(kunde) : "");

  const kundeNavn =
    t.kunde_navn ||
    t.kundeNavn ||
    (kunde ? kunde.navn || "" : "");

  return { kundeNr, kundeNavn };
}

function tegnTimer() {
  const timerTabell = document.getElementById("timerTabell");
  if (!timerTabell) return;

  const timerData = window.timer || [];

  timerTabell.innerHTML = "";

  if (!timerData.length) {
    timerTabell.innerHTML = `<tr><td colspan="10">Ingen timer registrert.</td></tr>`;
    return;
  }

  timerData.forEach(t => {
    const tr = document.createElement("tr");
    const kundeInfo = kundeInfoForTimer(t);

    tr.innerHTML = `
      <td>${t.dato || ""}</td>
      <td>${kundeInfo.kundeNr || ""}<br>${kundeInfo.kundeNavn || ""}</td>
      <td>${t.start || ""}</td>
      <td>${t.slutt || ""}</td>
      <td>${t.timer || 0}</td>
      <td>${Number(t.sum || 0).toFixed(2)}</td>
      <td>${t.fakturerbar ? "Ja" : "Nei"}</td>
    `;

    timerTabell.appendChild(tr);
  });
}

function nullstillSkjema() {
  settFeltHvisFinnes("startTid", "");
  settFeltHvisFinnes("sluttTid", "");
  settFeltHvisFinnes("beskrivelse", "");

  settFeltHvisFinnes("kundeNrVisning", "");
  settFeltHvisFinnes("prosjektValg", "");
  if (typeof fyllProsjektDropdown === "function") fyllProsjektDropdown();
  settFeltHvisFinnes("utgiftType", "");
  settFeltHvisFinnes("utgiftBelop", "0");

  const kundeValg = document.getElementById("kundeValg");
  if (kundeValg) {
    kundeValg.value = "";
    kundeValg.selectedIndex = 0;
  }

  const fakturerbar = document.getElementById("fakturerbar");
  if (fakturerbar) fakturerbar.value = "ja";

  const startTid = document.getElementById("startTid");
  if (startTid) startTid.focus();
}

function round(tall) {
  return Math.round(tall * 100) / 100;
}

window.lastTimer = lastTimer;
window.lagreTimer = lagreTimer;
window.settDagensDato = settDagensDato;
window.tegnTimer = tegnTimer;
function lagMvaExcel() {
  const fakturerte = (window.timer || []).filter(t =>
    t.fakturanr || t.faktura_nr
  );

  if (!fakturerte.length) {
    alert("Ingen fakturerte timer funnet.");
    return;
  }

  const rows = fakturerte.map(t => {
    const eksMva = Number(t.sum || 0);
    const mva = eksMva * 0.25;
    const inklMva = eksMva + mva;

    return {
      Fakturanr: t.fakturanr || t.faktura_nr || "",
      Dato: t.dato || "",
      Kundenr: t.kunde_nr || "",
      Kunde: t.kunde_navn || "",
      "Eks MVA": eksMva,
      MVA: mva,
      "Inkl MVA": inklMva
    };
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);

  XLSX.utils.book_append_sheet(wb, ws, "MVA");
  XLSX.writeFile(wb, "mva_rapport.xlsx");
}

const excelKnapp = document.getElementById("excelKnapp");
if (excelKnapp) {
  excelKnapp.onclick = lagMvaExcel;
}