const MVA_SATS = 0.25;
const LOGO_URL = window.location.origin + "/NyTimerdelt/logo.jpg";


async function lagEnFakturaPdf(
  kunde,
  fakturaTimer,
  maaned,
  firma,
  erKopi = false,
  eksisterendeFakturanr = null
) {
  const jspdfObj = window.jspdf;

  if (!jspdfObj || !jspdfObj.jsPDF) {
    alert("PDF-biblioteket er ikke lastet.");
    return;
  }

  const doc = new jspdfObj.jsPDF();

  const summer = summerTimerMedMva(fakturaTimer);
  const fakturaDato = new Date();
  const forfallsDato = leggTilDager(fakturaDato, 14);

  const fakturanr =
    eksisterendeFakturanr ||
    fakturaTimer[0]?.fakturanr ||
    fakturaTimer[0]?.faktura_nr ||
    (
      "F-" +
      formatDatoISO(fakturaDato).replaceAll("-", "") +
      "-" +
      Math.floor(Math.random() * 9000 + 1000)
    );

  if (typeof tegnBrevhodePdf === "function") {
    await tegnBrevhodePdf(doc, firma);
  } else {
    await leggTilLogo(doc);
  }

  let y = 90;

  doc.setFontSize(20);
  doc.text("FAKTURA", 14, y);

  if (erKopi) {
    doc.setFontSize(16);
    doc.text("KOPI", 165, y);
  }

  let hoyreY = 95;

  doc.setFontSize(10);

  doc.text("Forfallsdato", 140, hoyreY);
  doc.text(formatDatoISO(forfallsDato), 175, hoyreY);

  hoyreY += 6;

  doc.text("Kontonr", 140, hoyreY);
  doc.text(firma.kontonr || "", 175, hoyreY);

  hoyreY += 6;

  doc.text("Fakturanr", 140, hoyreY);
  doc.text(fakturanr, 175, hoyreY);

  hoyreY += 6;

  doc.text("Dato", 140, hoyreY);
  doc.text(formatDatoISO(fakturaDato), 175, hoyreY);

  hoyreY += 6;

  doc.text("Kundenr", 140, hoyreY);
  doc.text(hentKundeNr(kunde, fakturaTimer[0]), 175, hoyreY);

  y += 25;

  doc.setFontSize(12);
  doc.text(hentKundeNavn(kunde, fakturaTimer[0]), 14, y);

  y += 6;

  doc.setFontSize(10);

  if (kunde && kunde.adresse) {
    doc.text(kunde.adresse, 14, y);
    y += 5;
  }

  if (kunde && kunde.postadresse) {
    doc.text(kunde.postadresse, 14, y);
    y += 5;
  }

  y += 10;

  doc.text("Dato", 14, y);
  doc.text("Beskrivelse", 45, y);
  doc.text("Timer", 120, y);
  doc.text("Eks mva", 145, y);
  doc.text("MVA", 170, y);

  y += 4;

  if (typeof tegnSkilleLinjePdf === "function") {
    tegnSkilleLinjePdf(doc, y);
  } else {
    doc.line(14, y, 195, y);
  }

  y += 7;

  for (const t of fakturaTimer) {
    if (y > 250) {
      doc.addPage();

      if (typeof tegnBrevhodePdf === "function") {
        await tegnBrevhodePdf(doc, firma);
      } else {
        await leggTilLogo(doc);
      }

      y = 90;

      doc.setFontSize(10);

      doc.text("Dato", 14, y);
      doc.text("Beskrivelse", 45, y);
      doc.text("Timer", 120, y);
      doc.text("Eks mva", 145, y);
      doc.text("MVA", 170, y);

      y += 4;

      if (typeof tegnSkilleLinjePdf === "function") {
        tegnSkilleLinjePdf(doc, y);
      } else {
        doc.line(14, y, 195, y);
      }

      y += 7;
    }
const prosjekt =
  (window.prosjekter || []).find(p =>
    String(p.id || "") === String(t.prosjekt_id || "")
  );

const prosjektTekst =
  prosjekt
    ? `${prosjekt.prosjektnr || ""} ${prosjekt.navn || ""}`.trim()
    : "";

const linje = beregnMvaLinje(t);

const tekst = String(
  (prosjektTekst ? prosjektTekst + " - " : "") +
  (t.beskrivelse || t.kommentar || "Timer")
).slice(0, 40);

    doc.text(String(t.dato || ""), 14, y);
    doc.text(tekst, 45, y);
    doc.text(String(t.timer || 0), 120, y);
    doc.text(formatBelop(linje.sumEksMva), 145, y);
    doc.text(formatBelop(linje.mva), 170, y);

    y += 6;
  }

  y += 4;

  if (typeof tegnSkilleLinjePdf === "function") {
    tegnSkilleLinjePdf(doc, y, 120, 195);
  } else {
    doc.line(120, y, 195, y);
  }

  y += 8;

  doc.setFontSize(11);

  doc.text("Sum eks mva:", 130, y);
  doc.text(formatBelop(summer.sumEksMva) + " kr", 170, y);

  y += 6;

  doc.text("MVA 25%:", 130, y);
  doc.text(formatBelop(summer.mva) + " kr", 170, y);

  y += 6;

  doc.setFontSize(12);

  doc.text("Sum inkl mva:", 130, y);
  doc.text(formatBelop(summer.sumInkMva) + " kr", 170, y);

  if (typeof tegnBrevfotAlleSiderPdf === "function") {
    tegnBrevfotAlleSiderPdf(doc, firma);
  }

  const filnavn =
    `${tryggFilnavn(hentKundeNavn(kunde, fakturaTimer[0]))}_${maaned}${erKopi ? "_KOPI" : ""}.pdf`;

  doc.save(filnavn);

  if (!erKopi) {
    await sperrFakturerteTimer(fakturaTimer, fakturanr);
  }
}

async function lagFakturaPdf() {
  const melding = document.getElementById("timerMelding");

  try {
    const maaned = hentValgtMaaned();
    const firma = await hentFirmaData();
    const valgtKunde = hentValgtKunde();

    const timerForMaaned =
      (window.timer || [])
        .filter(t => !erAlleredeFakturert(t))
        .filter(t => String(t.dato || "").slice(0, 7) === maaned)
        .filter(t => erSammeKunde(t, valgtKunde));

    if (!timerForMaaned.length) {
      if (melding) {
        melding.textContent =
          "Fant ingen fakturerbare timer. De kan allerede være fakturert.";
      }

      return;
    }

    console.log("TIMER FOR MÅNED:", timerForMaaned);

    const grupper = grupperTimerPerKunde(timerForMaaned);
    console.log("GRUPPER:", grupper);

const kunde =
  valgtKunde ||
  finnKundeForTime(timerForMaaned[0]) ||
  null;

await lagEnFakturaPdf(
  kunde,
  timerForMaaned,
  maaned,
  firma,
  false
);
    if (melding) {
      melding.textContent =
        "Faktura PDF laget. Timene er sperret mot ny fakturering.";
    }

    if (typeof fyllKreditnotaFakturaValg === "function") {
      fyllKreditnotaFakturaValg();
    }
  } catch (e) {
    const feiltekst =
      "Faktura feilet: " +
      (e && e.message ? e.message : String(e));

    console.error("Faktura feilet:", e);

    if (melding) {
      melding.textContent = feiltekst;
    }

    alert(feiltekst);
  }
}

function fyllFakturaKopiValg() {
  if (typeof window.fyllFellesFakturaValg === "function") {
    window.fyllFellesFakturaValg(
      "fakturaKopiValg",
      "Velg faktura for kopi",
      "Ingen fakturaer funnet"
    );
    return;
  }
}

function hentFakturaKopiSelect() {
  return (
    document.getElementById("fakturaKopiValg") ||
    document.getElementById("fakturaKopiFakturaValg")
  );
}

function hentValgtFakturanrForKopi() {
  const select = hentFakturaKopiSelect();

  if (!select) {
    return "";
  }

  let verdi = String(select.value || "").trim();

  if (!verdi && select.selectedIndex >= 0) {
    verdi = String(select.options[select.selectedIndex].text || "").trim();
  }

  return verdi;
}

async function lagFakturaKopiPdf() {
  const omrade = document.getElementById("fakturaKopiOmrade");
  const select = hentFakturaKopiSelect();
  const melding = document.getElementById("timerMelding");

  if (!select) {
    alert("Fant ikke nedtrekksliste for faktura.");
    return;
  }

  const fakturanr = hentValgtFakturanrForKopi();

  if (!fakturanr) {
    alert("Velg faktura først.");
    return;
  }

  try {
    if (melding) {
      melding.textContent = "Starter utskrift av fakturakopi...";
    }

    console.log("Valgt faktura for kopi:", fakturanr);

    const kopiTimer = (window.timer || []).filter(t => {
      const nr = String(t.fakturanr || t.faktura_nr || "").trim();
      return nr === fakturanr;
    });

    console.log("Timer funnet på faktura:", kopiTimer);

    if (!kopiTimer.length) {
      alert("Fant ingen timer på valgt faktura: " + fakturanr);
      return;
    }

    const firma = await hentFirmaData();
    const kunde = finnKundeForTime(kopiTimer[0]) || null;
    const maaned = String(kopiTimer[0].dato || new Date().toISOString()).slice(0, 7);

    await lagEnFakturaPdf(
      kunde,
      kopiTimer,
      maaned,
      firma,
      true,
      fakturanr
    );

    if (omrade) {
      omrade.style.display = "none";
    }

    if (melding) {
      melding.textContent = "Fakturakopi laget.";
    }
  } catch (e) {
    console.error("Fakturakopi feilet:", e);
    alert("Fakturakopi feilet: " + (e.message || e));
  }
}

function kobleFakturaKnapp() {
  const pdfKnapp = document.getElementById("pdfKnapp");

  if (!pdfKnapp) {
    console.warn("Fant ikke pdfKnapp");
    return;
  }

  pdfKnapp.onclick = async function () {
    await lagFakturaPdf();
  };
}

function kobleFakturaKopiKnapp() {
  const kopiKnapp = document.getElementById("fakturaKopiKnapp");
  const skrivUtKopiKnapp = document.getElementById("skrivUtFakturaKopiKnapp");

  if (kopiKnapp) {
    kopiKnapp.onclick = function () {
      const kopiOmrade = document.getElementById("fakturaKopiOmrade");
      const kreditOmrade = document.getElementById("kreditnotaOmrade");

      if (kreditOmrade) kreditOmrade.style.display = "none";
      if (kopiOmrade) kopiOmrade.style.display = "block";

      fyllFakturaKopiValg();
    };
  }

  if (skrivUtKopiKnapp) {
    skrivUtKopiKnapp.onclick = async function () {
      await lagFakturaKopiPdf();
    };
  }
}

function kobleKreditnotaVisning() {
  const kreditKnapp = document.getElementById("kreditnotaKnapp");

  if (kreditKnapp) {
    kreditKnapp.onclick = function () {
      const kopiOmrade = document.getElementById("fakturaKopiOmrade");
      const kreditOmrade = document.getElementById("kreditnotaOmrade");

      if (kopiOmrade) kopiOmrade.style.display = "none";
      if (kreditOmrade) kreditOmrade.style.display = "block";

      if (typeof fyllKreditnotaFakturaValg === "function") {
        fyllKreditnotaFakturaValg();
      }
    };
  }
}

function fyllKreditnotaFakturaValg() {
  if (typeof window.fyllFellesFakturaValg === "function") {
    window.fyllFellesFakturaValg(
      "kreditnotaFakturaValg",
      "Velg faktura å kreditere",
      "Ingen fakturaer funnet"
    );
    return;
  }
}

async function lagKreditnotaPdf() {
  const select =
    document.getElementById("kreditnotaFakturaValg");

  if (!select || !select.value) {
    alert("Velg faktura først.");
    return;
  }

  const fakturanr = select.value;

  const kreditTimer =
    (window.timer || []).filter(t =>
      String(t.fakturanr || t.faktura_nr || "") === fakturanr
    );

  if (!kreditTimer.length) {
    alert("Fant ingen timer.");
    return;
  }

  const jspdfObj = window.jspdf;

  if (!jspdfObj || !jspdfObj.jsPDF) {
    alert("PDF-biblioteket er ikke lastet.");
    return;
  }

  const firma = await hentFirmaData();
  const doc = new jspdfObj.jsPDF();

  if (typeof tegnBrevhodePdf === "function") {
    await tegnBrevhodePdf(doc, firma);
  } else if (typeof leggTilLogo === "function") {
    await leggTilLogo(doc);
  }

  const kunde = finnKundeForTime(kreditTimer[0]) || null;
  const summer = summerTimerMedMva(kreditTimer);
  const kreditnotaNr = "KREDIT-" + fakturanr;

  let y = 70;

  doc.setFontSize(20);
  doc.text("KREDITNOTA", 14, y);

  doc.setFontSize(10);
  doc.text("Kreditnota nr", 140, y);
  doc.text(kreditnotaNr, 175, y);

  y += 6;
  doc.text("Krediterer faktura", 140, y);
  doc.text(String(fakturanr || ""), 175, y);

  y += 6;
  doc.text("Dato", 140, y);
  doc.text(formatDatoISO(new Date()), 175, y);

  y = 95;

  doc.setFontSize(11);
  doc.text("Kunde", 14, y);
  y += 6;

  doc.setFontSize(10);
  doc.text(hentKundeNavn(kunde, kreditTimer[0]), 14, y);
  y += 6;

  const kundeAdresse = kunde?.adresse || kreditTimer[0]?.kunde_adresse || "";
  const kundePostadresse = kunde?.postadresse || kreditTimer[0]?.kunde_postadresse || "";

  if (kundeAdresse) {
    doc.text(kundeAdresse, 14, y);
    y += 6;
  }

  if (kundePostadresse) {
    doc.text(kundePostadresse, 14, y);
    y += 6;
  }

  y += 10;

  doc.setFontSize(10);
  doc.text("Beskrivelse", 14, y);
  doc.text("Beløp eks. mva", 145, y);

  if (typeof tegnSkilleLinjePdf === "function") {
    tegnSkilleLinjePdf(doc, y + 2);
  } else {
    doc.line(14, y + 2, 195, y + 2);
  }

  y += 10;

  doc.text("Kreditering av faktura " + String(fakturanr || ""), 14, y);
  doc.text("-" + formatBelop(summer.sumEksMva) + " kr", 145, y);

  y += 20;

  doc.setFontSize(11);
  doc.text("Sum eks. mva", 120, y);
  doc.text("-" + formatBelop(summer.sumEksMva) + " kr", 165, y);

  y += 7;
  doc.text("MVA", 120, y);
  doc.text("-" + formatBelop(summer.mva) + " kr", 165, y);

  y += 7;
  doc.setFontSize(12);
  doc.text("Sum inkl. mva", 120, y);
  doc.text("-" + formatBelop(summer.sumInkMva) + " kr", 165, y);

  if (typeof tegnBrevfotAlleSiderPdf === "function") {
    tegnBrevfotAlleSiderPdf(doc, firma);
  }

  doc.save("kreditnota_" + tryggFilnavn(fakturanr) + ".pdf");

  const kreditOmrade = document.getElementById("kreditnotaOmrade");
  if (kreditOmrade) kreditOmrade.style.display = "none";

  alert("Kreditnota laget.");
}

function kobleKreditnotaKnapp() {
  const knapp =
    document.getElementById("skrivUtKreditnotaKnapp");

  if (!knapp) {
    return;
  }

  knapp.onclick = async function () {
    await lagKreditnotaPdf();
  };
}

kobleFakturaKnapp();
kobleFakturaKopiKnapp();
kobleKreditnotaVisning();
kobleKreditnotaKnapp();