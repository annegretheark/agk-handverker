console.log("NY timer.js er lastet");

function settDagensDato() {
  const dato = document.getElementById("dato");
  if (dato && !dato.value) {
    dato.value = new Date().toISOString().split("T")[0];
  }
}

async function lastTimer() {
  let query = supabaseClient
    .from("timer")
    .select("*")
    .order("dato", { ascending: false });

  if (!erAdmin && window.innloggetAnsattId) {
    query = query.eq("ansatt_id", window.innloggetAnsattId);
  }

  const { data, error } = await query;

  if (error) {
    const skjemaMelding = document.getElementById("skjemaMelding");
    if (skjemaMelding) skjemaMelding.textContent = "Feil ved henting av timer: " + error.message;
    console.error("Feil ved henting av timer:", error);
    return;
  }

  timer = data || [];
  window.timer = timer;
  tegnTimer();
}

function tallFraFelt(id) {
  const felt = document.getElementById(id);
  if (!felt) return 0;
  const verdi = String(felt.value || "").replace(",", ".").trim();
  return verdi === "" ? 0 : Number(verdi);
}

async function lagreTimer() {
  const ansattId = window.innloggetAnsattId || "";
  const skjemaMelding = document.getElementById("skjemaMelding");
  if (skjemaMelding) skjemaMelding.textContent = "";

  const kundeValg = document.getElementById("kundeValg");
  const valgtKunde = typeof finnKundeFraValg === "function"
    ? finnKundeFraValg(kundeValg.value)
    : kunder.find(k =>
        String(k.id || "") === String(kundeValg.value) ||
        String(k.kundenr || "") === String(kundeValg.value) ||
        String(k.kunde_nr || "") === String(kundeValg.value)
      );
  const valgtKundeNr = typeof hentKundeNr === "function"
    ? hentKundeNr(valgtKunde)
    : (valgtKunde?.kundenr || valgtKunde?.kunde_nr || valgtKunde?.id || kundeValg.value);
  const valgtKundeId = valgtKunde?.id || null;

  const diett = tallFraFelt("diett");
  const parkering = tallFraFelt("parkering");
  const billetter = tallFraFelt("billetter");
  const bompenger = tallFraFelt("bompenger");
  const andreUtlegg = tallFraFelt("andreUtlegg");
  const sumUtlegg = diett + parkering + billetter + bompenger + andreUtlegg;

  const registrering = {
    dato: document.getElementById("dato").value,
    kundeId: valgtKundeId,
    kundeNr: valgtKundeNr,
    kundeNavn: valgtKunde ? valgtKunde.navn : "",
    kunde: valgtKunde ? `${valgtKundeNr} - ${valgtKunde.navn}` : kundeValg.value,
    start: document.getElementById("startTid").value,
    slutt: document.getElementById("sluttTid").value,
    timepris: tallFraFelt("timepris"),
    km: tallFraFelt("km"),
    kmPris: tallFraFelt("kmPris"),
    diett,
    parkering,
    billetter,
    bompenger,
    andreUtlegg,
    sumUtlegg,
    andreUtleggBeskrivelse: document.getElementById("andreUtleggBeskrivelse").value.trim(),
    fakturerbar: document.getElementById("fakturerbar").checked,
    beskrivelse: document.getElementById("beskrivelse").value.trim()
  };

  if (!registrering.dato || !registrering.kundeId || !registrering.start || !registrering.slutt) {
    if (skjemaMelding) skjemaMelding.textContent = "Fyll inn dato, kunde, start og slutt.";
    return;
  }

  if (!ansattId) {
    if (skjemaMelding) skjemaMelding.textContent = "Fant ikke innlogget ansatt. Logg ut og inn igjen.";
    return;
  }

  const nyStartMin = tidTilMinutter(registrering.start);
  let nySluttMin = tidTilMinutter(registrering.slutt);
  if (nySluttMin <= nyStartMin) nySluttMin += 24 * 60;

  let duplikatQuery = supabaseClient
    .from("timer")
    .select("id,start,slutt,kunde_id,kunde_nr,kunde_navn")
    .eq("ansatt_id", ansattId)
    .eq("dato", registrering.dato);

  if (registrering.kundeId) {
    duplikatQuery = duplikatQuery.eq("kunde_id", registrering.kundeId);
  } else {
    duplikatQuery = duplikatQuery.eq("kunde_nr", registrering.kundeNr);
  }

  const { data: eksisterendeTimer, error: duplikatError } = await duplikatQuery;

  if (duplikatError) {
    console.error("Feil ved sjekk av dobbeltregistrering:", duplikatError);
    if (skjemaMelding) {
      skjemaMelding.textContent = "Kunne ikke sjekke dobbeltregistrering: " + duplikatError.message;
    }
    return;
  }

  const overlapp = (eksisterendeTimer || []).find(t => {
    const gammelStartMin = tidTilMinutter(t.start);
    let gammelSluttMin = tidTilMinutter(t.slutt);
    if (gammelSluttMin <= gammelStartMin) gammelSluttMin += 24 * 60;

    return nyStartMin < gammelSluttMin && nySluttMin > gammelStartMin;
  });

  if (overlapp) {
    const kundeTekst = overlapp.kunde_navn ? " for " + overlapp.kunde_navn : "";
    if (skjemaMelding) {
      skjemaMelding.textContent = `Du har allerede registrert timer ${overlapp.start}-${overlapp.slutt}${kundeTekst} denne datoen.`;
    }
    return;
  }

  const finnesFraFor = timer.some(t =>
    String(t.ansatt_id || "") === String(ansattId) &&
    String(t.dato || "") === String(registrering.dato) &&
    String(t.kunde_nr || t.kundeNr || "") === String(registrering.kundeNr) &&
    String(t.start || "") === String(registrering.start) &&
    String(t.slutt || "") === String(registrering.slutt)
  );

  if (finnesFraFor) {
    if (skjemaMelding) skjemaMelding.textContent = "Denne registreringen finnes allerede.";
    return;
  }

  const beregning = beregnTimer(
    registrering.start,
    registrering.slutt,
    registrering.timepris
  );

  registrering.timer = beregning.timer;
  registrering.overtid50 = beregning.overtid50;
  registrering.overtid100 = beregning.overtid100;
  registrering.sumTimer = beregning.sumTimer;
  registrering.sumKm = registrering.km * registrering.kmPris;

  registrering.sum = registrering.fakturerbar
    ? registrering.sumTimer + registrering.sumKm + registrering.sumUtlegg
    : 0;

  const supabaseTimer = {
    ansatt_id: ansattId,
    dato: registrering.dato,
    kunde_id: registrering.kundeId,
    kunde_nr: registrering.kundeNr,
    kunde_navn: registrering.kundeNavn,
    start: registrering.start,
    slutt: registrering.slutt,
    timer: registrering.timer,
    overtid50: registrering.overtid50,
    overtid100: registrering.overtid100,
    timepris: registrering.timepris,
    km: registrering.km,
    km_pris: registrering.kmPris,
    sum_timer: registrering.sumTimer,
    sum_km: registrering.sumKm,
    diett: registrering.diett,
    parkering: registrering.parkering,
    billetter: registrering.billetter,
    bompenger: registrering.bompenger,
    andre_utlegg: registrering.sumUtlegg,
    andre_utlegg_beskrivelse: registrering.andreUtleggBeskrivelse,
    sum: registrering.sum,
    fakturerbar: registrering.fakturerbar,
    beskrivelse: registrering.beskrivelse
  };

  const { error } = await supabaseClient
    .from("timer")
    .insert([supabaseTimer]);

  if (error) {
    console.error("Feil ved lagring av timer:", error);
    if (skjemaMelding) {
      skjemaMelding.textContent = "Feil ved lagring av timer: " + error.message;
    }
    return;
  }

  await lastTimer();
  nullstillSkjema();

  if (skjemaMelding) {
    skjemaMelding.textContent = "Timer er lagret.";
  }
}

function tidTilMinutter(tid) {
  if (!tid || !String(tid).includes(":")) return 0;
  const [timerDel, minuttDel] = String(tid).split(":");
  return Number(timerDel) * 60 + Number(minuttDel);
}

function beregnTimer(start, slutt, pris) {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = slutt.split(":").map(Number);

  let startMin = sh * 60 + sm;
  let sluttMin = eh * 60 + em;

  if (sluttMin <= startMin) {
    sluttMin += 24 * 60;
  }

  let vanligeMin = 0;
  let overtid50Min = 0;
  let overtid100Min = 0;

  for (let min = startMin; min < sluttMin; min++) {
    const klokkeMin = min % (24 * 60);

    if (klokkeMin >= 21 * 60 || klokkeMin < 6 * 60) {
      overtid100Min++;
    } else if (klokkeMin >= 17 * 60 && klokkeMin < 21 * 60) {
      overtid50Min++;
    } else {
      vanligeMin++;
    }
  }

  const vanligeTimer = vanligeMin / 60;
  const overtid50 = overtid50Min / 60;
  const overtid100 = overtid100Min / 60;
  const timerTotalt = (sluttMin - startMin) / 60;

  const sumTimer =
    vanligeTimer * pris +
    overtid50 * pris * 1.5 +
    overtid100 * pris * 2;

  return {
    timer: round(timerTotalt),
    overtid50: round(overtid50),
    overtid100: round(overtid100),
    sumTimer: round(sumTimer)
  };
}


function kundeInfoForTimer(t) {
  const kunde = (window.kunder || kunder || []).find(k =>
    String(k.id || "") === String(t.kunde_id || "") ||
    String(k.kundenr || "") === String(t.kunde_nr || t.kundeNr || "") ||
    String(k.kunde_nr || "") === String(t.kunde_nr || t.kundeNr || "")
  );

  const kundeNr =
    t.kunde_nr ||
    t.kundeNr ||
    (kunde ? (typeof hentKundeNr === "function" ? hentKundeNr(kunde) : (kunde.kundenr || kunde.kunde_nr || kunde.id || "")) : "");

  const kundeNavn =
    t.kunde_navn ||
    t.kundeNavn ||
    (kunde ? (kunde.navn || "") : "") ||
    t.kunde ||
    "";

  return { kundeNr, kundeNavn };
}

function tegnTimer() {
  const timerTabell = document.getElementById("timerTabell");
  if (!timerTabell) return;

  timerTabell.innerHTML = "";

  if (!timer || timer.length === 0) {
    timerTabell.innerHTML = `<tr><td colspan="10">Ingen timer registrert.</td></tr>`;
    return;
  }

  timer.forEach(t => {
    const tr = document.createElement("tr");
    const utlegg = Number(t.andre_utlegg || t.sumUtlegg || 0);
    const kundeInfo = kundeInfoForTimer(t);

    tr.innerHTML = `
      <td>${t.dato || ""}</td>
      <td>${kundeInfo.kundeNr || ""}<br>${kundeInfo.kundeNavn || ""}</td>
      <td>${t.start || ""}</td>
      <td>${t.slutt || ""}</td>
      <td>${t.timer || 0}</td>
      <td>50%: ${t.overtid50 || 0}<br>100%: ${t.overtid100 || 0}</td>
      <td>${t.km || 0}</td>
      <td>
        ${utlegg}<br>
        ${Number(t.diett || 0) ? "Diett: " + t.diett + "<br>" : ""}
        ${Number(t.parkering || 0) ? "Parkering: " + t.parkering + "<br>" : ""}
        ${Number(t.billetter || 0) ? "Billetter: " + t.billetter + "<br>" : ""}
        ${Number(t.bompenger || 0) ? "Bompenger: " + t.bompenger + "<br>" : ""}
        ${t.andre_utlegg_beskrivelse || ""}
      </td>
      <td>${Number(t.sum || 0).toFixed(2)}</td>
      <td>${t.fakturerbar ? "Ja" : "Nei"}</td>
    `;

    timerTabell.appendChild(tr);
  });
}

function nullstillSkjema() {
  document.getElementById("startTid").value = "";
  document.getElementById("sluttTid").value = "";
  document.getElementById("km").value = "0";
  document.getElementById("diett").value = "0";
  document.getElementById("parkering").value = "0";
  document.getElementById("billetter").value = "0";
  document.getElementById("bompenger").value = "0";
  document.getElementById("andreUtlegg").value = "0";
  document.getElementById("andreUtleggBeskrivelse").value = "";
  document.getElementById("beskrivelse").value = "";
  document.getElementById("fakturerbar").checked = true;
  document.getElementById("startTid").focus();
}

function round(tall) {
  return Math.round(tall * 100) / 100;
}

window.lastTimer = lastTimer;
window.lagreTimer = lagreTimer;
window.settDagensDato = settDagensDato;
window.tegnTimer = tegnTimer;
