console.log("lonn.js er lastet");

let sisteLonnData = [];
let sisteFirma = {};

function lonnMelding(tekst, erFeil = false) {
  const el = document.getElementById("lonnMelding");
  if (el) {
    el.textContent = tekst || "";
    el.style.color = erFeil ? "#b42318" : "#116329";
  }
}

function lonnTall(verdi) {
  if (verdi === null || verdi === undefined || verdi === "") return 0;
  const n = Number(String(verdi).replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

function lonnRund(n) {
  return Math.round((lonnTall(n) + Number.EPSILON) * 100) / 100;
}

function kroner(n) {
  return lonnRund(n).toLocaleString("no-NO", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function finnTimerAntall(rad) {
  if (rad.timer !== undefined && rad.timer !== null) return lonnTall(rad.timer);
  if (rad.antall_timer !== undefined) return lonnTall(rad.antall_timer);
  if (rad.start && rad.slutt && typeof tidTilMinutter === "function") {
    let start = tidTilMinutter(rad.start);
    let slutt = tidTilMinutter(rad.slutt);
    if (slutt <= start) slutt += 24 * 60;
    return (slutt - start) / 60;
  }
  return 0;
}

function hentAnsattNavn(ansatt, ansattId) {
  return ansatt?.navn || ansatt?.name || ansatt?.epost || ansatt?.email || ansattId || "Ukjent ansatt";
}

function hentTimelonn(ansatt, timerad) {
  return lonnTall(ansatt?.timelonn || ansatt?.time_lonn || ansatt?.timepris || timerad?.timelonn || timerad?.timepris);
}

function beregnSkatt(brutto, ansatt) {
  const skattVerdi = lonnTall(ansatt?.skattetrekk || ansatt?.skatt || ansatt?.skatteprosent);
  if (skattVerdi <= 0) return 0;
  if (skattVerdi <= 100) return lonnRund(brutto * skattVerdi / 100);
  return lonnRund(skattVerdi);
}

function hentAndreTrekk(ansatt) {
  const felt = ["pensjon", "fagforening", "andre_trekk", "trekk"];
  let sum = 0;
  const detaljer = {};
  felt.forEach(f => {
    const verdi = lonnTall(ansatt?.[f]);
    if (verdi) {
      const navn = f === "andre_trekk" ? "Andre trekk" : f.charAt(0).toUpperCase() + f.slice(1);
      detaljer[navn] = verdi;
      sum += verdi;
    }
  });
  return { sum: lonnRund(sum), detaljer };
}

async function hentOgBeregnLonn() {
  if (typeof supabaseClient === "undefined") {
    throw new Error("Supabase er ikke lastet. Sjekk at config.js lastes før app.js.");
  }

  const [timerRes, ansatteRes, firmaRes] = await Promise.all([
    supabaseClient.from("timer").select("*"),
    supabaseClient.from("ansatte").select("*"),
    supabaseClient.from("firma").select("*").order("id", { ascending: true }).limit(1).maybeSingle()
  ]);

  if (timerRes.error) throw new Error("Feil ved henting av timer: " + timerRes.error.message);
  if (ansatteRes.error) throw new Error("Feil ved henting av ansatte: " + ansatteRes.error.message);
  if (firmaRes.error) console.warn("Kunne ikke hente firma:", firmaRes.error);

  const timerader = timerRes.data || [];
  const ansatte = ansatteRes.data || [];
  sisteFirma = firmaRes.data || {};

  const ansatteMap = new Map(ansatte.map(a => [String(a.id), a]));
  const grupper = new Map();

  timerader.forEach(t => {
    const ansattId = String(t.ansatt_id || t.ansattId || t.ansatt || "");
    const ansatt = ansatteMap.get(ansattId) || {};
    const key = ansattId || hentAnsattNavn(ansatt, "Ukjent");

    if (!grupper.has(key)) {
      grupper.set(key, {
        ansattId,
        ansatt,
        ansattNavn: hentAnsattNavn(ansatt, ansattId),
        epost: ansatt.epost || ansatt.email || "",
        kontonr: ansatt.kontonr || ansatt.konto_nr || "",
        timer: 0,
        overtid50: 0,
        overtid100: 0,
        brutto: 0,
        skatt: 0,
        ekstraSkatt: lonnTall(ansatt.ekstra_skatt || ansatt.ekstraskatt || ansatt.ekstraSkatt),
        andreTrekk: 0,
        trekkDetaljer: {},
        feriepengerGrunnlag: 0,
        netto: 0,
        periodeFra: "",
        periodeTil: ""
      });
    }

    const g = grupper.get(key);
    const totalTimer = finnTimerAntall(t);
    const ot50 = lonnTall(t.overtid50 || t.overtid_50);
    const ot100 = lonnTall(t.overtid100 || t.overtid_100);
    const normalTimer = Math.max(totalTimer - ot50 - ot100, 0);
    const timelonn = hentTimelonn(ansatt, t);

    let bruttoRad = 0;
    if (timelonn > 0) {
      bruttoRad = normalTimer * timelonn + ot50 * timelonn * 1.5 + ot100 * timelonn * 2;
    } else {
      bruttoRad = lonnTall(t.sum_timer || t.sumTimer || t.sum || 0);
    }

    g.timer += totalTimer;
    g.overtid50 += ot50;
    g.overtid100 += ot100;
    g.brutto += bruttoRad;

    const dato = String(t.dato || "");
    if (dato) {
      if (!g.periodeFra || dato < g.periodeFra) g.periodeFra = dato;
      if (!g.periodeTil || dato > g.periodeTil) g.periodeTil = dato;
    }
  });

  const resultat = Array.from(grupper.values()).map(g => {
    const andre = hentAndreTrekk(g.ansatt);
    g.timer = lonnRund(g.timer);
    g.overtid50 = lonnRund(g.overtid50);
    g.overtid100 = lonnRund(g.overtid100);
    g.brutto = lonnRund(g.brutto);
    g.skatt = beregnSkatt(g.brutto, g.ansatt);
    g.ekstraSkatt = lonnRund(g.ekstraSkatt);
    g.andreTrekk = andre.sum;
    g.trekkDetaljer = andre.detaljer;
    g.feriepengerGrunnlag = g.brutto;
    g.netto = lonnRund(g.brutto - g.skatt - g.ekstraSkatt - g.andreTrekk);
    return g;
  }).sort((a, b) => a.ansattNavn.localeCompare(b.ansattNavn, "no"));

  sisteLonnData = resultat;
  return resultat;
}

async function kjorLonn() {
  try {
    lonnMelding("Henter timer og beregner lønn...");
    const data = await hentOgBeregnLonn();
    if (!data.length) {
      lonnMelding("Ingen timer funnet å beregne lønn fra.", true);
      return;
    }
    const sumNetto = data.reduce((s, r) => s + r.netto, 0);
    lonnMelding(`Lønn beregnet for ${data.length} ansatt(e). Netto utbetales: ${kroner(sumNetto)} kr`);
  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
    alert(e.message);
  }
}

async function eksporterTrekkExcel() {
  try {
    const data = sisteLonnData.length ? sisteLonnData : await hentOgBeregnLonn();
    const rader = data.map(r => ({
      Periode: `${r.periodeFra || ""} - ${r.periodeTil || ""}`,
      Ansatt: r.ansattNavn,
      Bruttolønn: r.brutto,
      Skatt: r.skatt,
      "Ekstra skatt": r.ekstraSkatt,
      Pensjon: r.trekkDetaljer.Pensjon || 0,
      Fagforening: r.trekkDetaljer.Fagforening || 0,
      "Andre trekk": r.trekkDetaljer["Andre trekk"] || 0,
      "Sum trekk": lonnRund(r.skatt + r.ekstraSkatt + r.andreTrekk),
      "Netto utbetales": r.netto,
      "Feriepengegrunnlag": r.feriepengerGrunnlag
    }));
    lagRegneark("trekk_oversikt.xlsx", "Trekk", rader);
    lonnMelding("Trekk Excel er laget.");
  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

async function eksporterUtbetalingerExcel() {
  try {
    const data = sisteLonnData.length ? sisteLonnData : await hentOgBeregnLonn();
    const rader = [];
    data.forEach(r => {
      rader.push({ Type: "Lønn", Mottaker: r.ansattNavn, Kontonr: r.kontonr, Beløp: r.netto });
      if (r.skatt || r.ekstraSkatt) rader.push({ Type: "Skatt", Mottaker: "Skatteetaten", Kontonr: "", Beløp: lonnRund(r.skatt + r.ekstraSkatt) });
      if (r.trekkDetaljer.Pensjon) rader.push({ Type: "Pensjon", Mottaker: "Pensjon", Kontonr: "", Beløp: r.trekkDetaljer.Pensjon });
      if (r.trekkDetaljer.Fagforening) rader.push({ Type: "Fagforening", Mottaker: "Fagforening", Kontonr: "", Beløp: r.trekkDetaljer.Fagforening });
      if (r.trekkDetaljer["Andre trekk"]) rader.push({ Type: "Andre trekk", Mottaker: "Andre trekk", Kontonr: "", Beløp: r.trekkDetaljer["Andre trekk"] });
    });
    rader.sort((a, b) => a.Type.localeCompare(b.Type, "no") || a.Mottaker.localeCompare(b.Mottaker, "no"));
    lagRegneark("utbetalinger_sortert_pa_type.xlsx", "Utbetalinger", rader);
    lonnMelding("Utbetalinger Excel er laget.");
  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

async function lagLonnsslipper() {
  try {
    const data = sisteLonnData.length ? sisteLonnData : await hentOgBeregnLonn();
    if (!data.length) {
      lonnMelding("Ingen lønnsslipper å lage.", true);
      return;
    }

    if (!window.jspdf || !window.jspdf.jsPDF) {
      alert("PDF-biblioteket er ikke lastet. Sjekk internett eller script-lenken til jsPDF.");
      return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    data.forEach((r, index) => {
      if (index > 0) doc.addPage();
      const firmaNavn = sisteFirma.navn || "Firma";
      const firmaAdresse = sisteFirma.adresse || "";
      const firmaEpost = sisteFirma.epost || sisteFirma.email || "";
      const konto = sisteFirma.kontonr || sisteFirma.konto_nr || "";

      if (sisteFirma.logo && String(sisteFirma.logo).startsWith("data:image")) {
        try { doc.addImage(sisteFirma.logo, "PNG", 150, 12, 35, 20); } catch (e) { console.warn("Logo kunne ikke legges inn i PDF", e); }
      }

      doc.setFontSize(18);
      doc.text("Lønnsslipp", 20, 20);
      doc.setFontSize(10);
      doc.text(firmaNavn, 20, 30);
      if (firmaAdresse) doc.text(firmaAdresse, 20, 36);
      if (firmaEpost) doc.text("E-post: " + firmaEpost, 20, 42);
      if (konto) doc.text("Konto: " + konto, 20, 48);

      doc.setFontSize(12);
      doc.text("Ansatt: " + r.ansattNavn, 20, 65);
      doc.text("Periode: " + (r.periodeFra || "") + " - " + (r.periodeTil || ""), 20, 73);

      let y = 90;
      const linjer = [
        ["Timer", r.timer],
        ["Overtid 50%", r.overtid50],
        ["Overtid 100%", r.overtid100],
        ["Bruttolønn", kroner(r.brutto) + " kr"],
        ["Feriepengegrunnlag", kroner(r.feriepengerGrunnlag) + " kr"],
        ["Skatt", kroner(r.skatt) + " kr"],
        ["Ekstra skatt", kroner(r.ekstraSkatt) + " kr"],
        ["Andre trekk", kroner(r.andreTrekk) + " kr"],
        ["Netto utbetales", kroner(r.netto) + " kr"]
      ];

      linjer.forEach(([navn, verdi]) => {
        doc.text(String(navn), 20, y);
        doc.text(String(verdi), 100, y);
        y += 8;
      });
    });

    doc.save("lonnsslipper.pdf");
    lonnMelding("PDF med lønnsslipper er laget.");
  } catch (e) {
    console.error(e);
    lonnMelding(e.message, true);
  }
}

function lagRegneark(filnavn, arkNavn, rader) {
  if (!rader || !rader.length) {
    alert("Ingen data å eksportere.");
    return;
  }

  if (window.XLSX) {
    const ws = XLSX.utils.json_to_sheet(rader);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, arkNavn);
    XLSX.writeFile(wb, filnavn);
    return;
  }

  const overskrifter = Object.keys(rader[0]);
  const csv = [overskrifter.join(";"), ...rader.map(rad => overskrifter.map(k => String(rad[k] ?? "").replaceAll(";", ",")).join(";"))].join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filnavn.replace(".xlsx", ".csv");
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

document.addEventListener("DOMContentLoaded", () => {
  const koblinger = [
    ["kjorLonnKnapp", kjorLonn],
    ["lonnsslippKnapp", lagLonnsslipper],
    ["trekkExcelKnapp", eksporterTrekkExcel],
    ["utbetalingExcelKnapp", eksporterUtbetalingerExcel]
  ];
  koblinger.forEach(([id, fn]) => {
    const knapp = document.getElementById(id);
    if (knapp) knapp.addEventListener("click", fn);
  });
});

window.kjorLonn = kjorLonn;
window.lagLonnsslipper = lagLonnsslipper;
window.eksporterTrekkExcel = eksporterTrekkExcel;
window.eksporterUtbetalingerExcel = eksporterUtbetalingerExcel;
