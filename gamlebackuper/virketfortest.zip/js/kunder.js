let kunder = [];

function settKundeMelding(tekst) {
  const el = document.getElementById("kundeMelding");
  if (el) el.textContent = tekst || "";
}

async function lastKunder() {
  const { data, error } = await supabaseClient
    .from("kunder")
    .select("*")
    .order("navn", { ascending: true });

  if (error) {
    console.error("Feil ved henting av kunder:", error);
    settKundeMelding("Feil ved henting av kunder: " + error.message);
    return;
  }

  kunder = data || [];
  window.kunder = kunder;
  visKunder();
  fyllKundeDropdown();
}

async function lagreKunde() {
  const id = document.getElementById("kundeId")?.value || "";

  const kunde = {
    navn: document.getElementById("kundeNavn").value.trim(),
    adresse: document.getElementById("kundeAdresse").value.trim(),
    epost: document.getElementById("kundeEpost").value.trim(),
    kontaktperson: document.getElementById("kundeKontaktperson").value.trim(),
    kontonr: document.getElementById("kundeKontonr").value.trim()
  };

  if (!kunde.navn) {
    settKundeMelding("Kundenavn må fylles ut.");
    return;
  }

  let result;
  if (id) {
    result = await supabaseClient.from("kunder").update(kunde).eq("id", id).select();
  } else {
    result = await supabaseClient.from("kunder").insert([kunde]).select();
  }

  if (result.error) {
    console.error("Feil ved lagring av kunde:", result.error);
    settKundeMelding("Feil ved lagring av kunde: " + result.error.message);
    return;
  }

  nullstillKundeSkjema();
  settKundeMelding("Kunde lagret i databasen.");
  await lastKunder();
}

function visKunder() {
  const liste = document.getElementById("kundeListe");
  if (!liste) return;

  liste.innerHTML = "";

  if (!kunder.length) {
    liste.innerHTML = "<p>Ingen kunder funnet.</p>";
    return;
  }

  kunder.forEach(kunde => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <strong>${kunde.navn || ""}</strong><br>
      ${kunde.adresse || ""}<br>
      ${kunde.epost || ""}<br>
      ${kunde.kontaktperson || ""}<br>
      ${kunde.kontonr || ""}<br>
      <button type="button" class="secondary" onclick="redigerKunde('${kunde.id}')">Rediger</button>
    `;
    liste.appendChild(div);
  });
}

function redigerKunde(id) {
  const kunde = kunder.find(k => String(k.id) === String(id));
  if (!kunde) return alert("Fant ikke kunde");

  if (document.getElementById("kundeId")) document.getElementById("kundeId").value = kunde.id;
  document.getElementById("kundeNavn").value = kunde.navn || "";
  document.getElementById("kundeAdresse").value = kunde.adresse || "";
  document.getElementById("kundeEpost").value = kunde.epost || "";
  document.getElementById("kundeKontaktperson").value = kunde.kontaktperson || "";
  document.getElementById("kundeKontonr").value = kunde.kontonr || "";
  settKundeMelding("Redigerer kunde. Trykk Lagre kunde når du er ferdig.");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function nullstillKundeSkjema() {
  if (document.getElementById("kundeId")) document.getElementById("kundeId").value = "";
  document.getElementById("kundeNavn").value = "";
  document.getElementById("kundeAdresse").value = "";
  document.getElementById("kundeEpost").value = "";
  document.getElementById("kundeKontaktperson").value = "";
  document.getElementById("kundeKontonr").value = "";
}

function hentKundeNr(kunde) {
  return kunde?.kundenr || kunde?.kunde_nr || kunde?.id || "";
}

function finnKundeFraValg(verdi) {
  return kunder.find(k =>
    String(k.id || "") === String(verdi) ||
    String(k.kundenr || "") === String(verdi) ||
    String(k.kunde_nr || "") === String(verdi)
  );
}

function fyllKundeDropdown() {
  const valg = document.getElementById("kundeValg");
  if (!valg) return;

  const valgt = valg.value;
  valg.innerHTML = `<option value="">Velg kunde</option>`;

  kunder.forEach(kunde => {
    const option = document.createElement("option");
    const kundeNr = hentKundeNr(kunde);
    option.value = kunde.id || kundeNr;
    option.textContent = `${kundeNr} - ${kunde.navn || ""}`;
    valg.appendChild(option);
  });

  if (valgt) valg.value = valgt;
}

function visKundeNavn() {
  const verdi = document.getElementById("kundeValg").value;
  const kunde = finnKundeFraValg(verdi);
  const visning = document.getElementById("kundeNavnVisning");
  if (visning) {
    const kundeNr = hentKundeNr(kunde);
    visning.textContent = kunde ? `${kundeNr} - ${kunde.navn || ""}` : "";
  }
}

window.kunder = kunder;
window.lastKunder = lastKunder;
window.lagreKunde = lagreKunde;
window.redigerKunde = redigerKunde;
window.fyllKundeDropdown = fyllKundeDropdown;
window.visKundeNavn = visKundeNavn;
window.hentKundeNr = hentKundeNr;
window.finnKundeFraValg = finnKundeFraValg;
window.lagreKunde = lagreKunde;
window.visKundeNavn = visKundeNavn;
window.tegnKundeListe = visKunder;
window.tegnKunder = fyllKundeDropdown;
