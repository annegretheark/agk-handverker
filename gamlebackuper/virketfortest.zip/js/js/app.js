console.log("NY app.js er lastet");

function koble(id, event, funksjon) {
  const element = document.getElementById(id);

  if (!element) {
    console.warn("Fant ikke element:", id);
    return;
  }

  if (typeof funksjon !== "function") {
    console.warn("Fant ikke funksjon for:", id);
    return;
  }

  element.addEventListener(event, funksjon);
}

function tryggFunksjon(navn) {
  return typeof window[navn] === "function" ? window[navn] : undefined;
}

koble("loginKnapp", "click", tryggFunksjon("loggInn"));
koble("glemtPassordKnapp", "click", tryggFunksjon("glemtPassord"));
koble("lagreNyttPassordKnapp", "click", tryggFunksjon("lagreNyttPassord"));
koble("tilbakeTilLoginKnapp", "click", tryggFunksjon("visLogin"));
koble("loggUtKnapp", "click", tryggFunksjon("loggUt"));

koble("visTimerKnapp", "click", tryggFunksjon("visTimerSide"));
koble("visKundeKnapp", "click", tryggFunksjon("visKundeSide"));
koble("visAnsattKnapp", "click", tryggFunksjon("visAnsattSide"));
koble("visFirmaKnapp", "click", tryggFunksjon("visFirmaSide"));

koble("leggTilKundeKnapp", "click", tryggFunksjon("lagreKunde"));
koble("tilbakeTilTimerKnapp", "click", tryggFunksjon("visTimerSide"));

koble("leggTilTrekkKnapp", "click", tryggFunksjon("leggTilTrekk"));
koble("lagreAnsattKnapp", "click", tryggFunksjon("lagreAnsatt"));
koble("tilbakeFraAnsattKnapp", "click", tryggFunksjon("visTimerSide"));

koble("lagreFirmaKnapp", "click", tryggFunksjon("lagreFirma"));
koble("firmaLogo", "change", tryggFunksjon("lastInnLogo"));
koble("tilbakeFraFirmaKnapp", "click", tryggFunksjon("visTimerSide"));

koble("lagreTimerKnapp", "click", tryggFunksjon("lagreTimer"));
koble("excelKnapp", "click", tryggFunksjon("eksporterMvaRegneark"));
koble("pdfKnapp", "click", tryggFunksjon("lagFakturaPdf"));
koble("backupKnapp", "click", tryggFunksjon("backup"));

const importFil = document.getElementById("importFil");
if (importFil && typeof window.importerBackup === "function") {
  importFil.addEventListener("change", window.importerBackup);
}

const kundeValg = document.getElementById("kundeValg");
if (kundeValg && typeof window.visKundeNavn === "function") {
  kundeValg.addEventListener("change", window.visKundeNavn);
}

const startTidFelt = document.getElementById("startTid");
if (startTidFelt) {
  startTidFelt.addEventListener("change", () => {
    const sluttTid = document.getElementById("sluttTid");
    if (sluttTid) sluttTid.focus();
  });
}

if (typeof supabaseClient !== "undefined") {
  supabaseClient.auth.onAuthStateChange((event) => {
    if (event === "PASSWORD_RECOVERY") {
      visNyttPassord();
    }
  });
}

function startApp() {
  console.log("Starter app");
  visLogin();
}

startApp();


// =====================================================
// LØNN - KUN TILLEGG
// Rører IKKE login, visLogin, loggInn eller Supabase auth.
// Legger bare inn lønnsknapper når appen/timersiden finnes.
// =====================================================

function leggTilLonnKnapperEtterLogin() {
  if (document.getElementById("lonnPanel")) return;

  const timerSide =
    document.getElementById("timerSide") ||
    document.getElementById("appSide") ||
    document.querySelector("main");

  if (!timerSide) {
    console.warn("Fant ikke timerSide/appSide/main. Lønnsknapper ikke lagt inn.");
    return;
  }

  const panel = document.createElement("section");
  panel.id = "lonnPanel";
  panel.style.marginTop = "16px";
  panel.style.padding = "14px";
  panel.style.border = "2px solid #1f6feb";
  panel.style.borderRadius = "10px";
  panel.style.background = "#fff";

  panel.innerHTML = `
    <h2>Lønn</h2>
    <p>Lønn hentes fra registrerte timer.</p>
    <button id="kjorLonnKnapp" type="button">Kjør lønn</button>
    <button id="lonnsslippKnapp" type="button">Lønnsslipper PDF</button>
    <button id="trekkExcelKnapp" type="button">Trekk Excel</button>
    <button id="utbetalingExcelKnapp" type="button">Utbetalinger Excel</button>
    <div id="lonnMelding" style="margin-top:10px;font-weight:bold;"></div>
  `;

  timerSide.appendChild(panel);

  koble("kjorLonnKnapp", "click", kjorLonn);
  koble("lonnsslippKnapp", "click", lagLonnsslipper);
  koble("trekkExcelKnapp", "click", eksporterTrekkExcel);
  koble("utbetalingExcelKnapp", "click", eksporterUtbetalingerExcel);
}

function kjorLonn() {
  const melding = document.getElementById("lonnMelding");
  if (melding) melding.textContent = "Lønn skal hentes fra registrerte timer.";
  alert("Kjør lønn virker. Neste steg er å koble til timer-tabellen.");
}

function lagLonnsslipper() {
  const melding = document.getElementById("lonnMelding");
  if (melding) melding.textContent = "Her lages PDF-lønnsslipper fra timer.";
  alert("Lønnsslipper PDF virker.");
}

function eksporterTrekkExcel() {
  const rader = [
    {
      Periode: "2026-05",
      Ansatt: "Eksempel",
      Skatt: 0,
      "Ekstra skatt": 0,
      Pensjon: 0,
      Fagforening: 0,
      "Andre trekk": 0,
      "Sum trekk": 0
    }
  ];

  lagCsvFil("trekk_oversikt.csv", rader);
}

function eksporterUtbetalingerExcel() {
  const rader = [
    { Type: "Fagforening", Mottaker: "Fagforening", Belop: 0 },
    { Type: "Lønn", Mottaker: "Ansatt", Belop: 0 },
    { Type: "Pensjon", Mottaker: "Pensjon", Belop: 0 },
    { Type: "Skatt", Mottaker: "Skatteetaten", Belop: 0 }
  ];

  rader.sort((a, b) => a.Type.localeCompare(b.Type, "no"));
  lagCsvFil("utbetalinger_sortert_pa_type.csv", rader);
}

function lagCsvFil(filnavn, rader) {
  if (!rader || rader.length === 0) {
    alert("Ingen data å eksportere.");
    return;
  }

  const overskrifter = Object.keys(rader[0]);

  const csv = [
    overskrifter.join(";"),
    ...rader.map(rad =>
      overskrifter
        .map(k => String(rad[k] ?? "").replaceAll(";", ","))
        .join(";")
    )
  ].join("\n");

  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const lenke = document.createElement("a");
  lenke.href = URL.createObjectURL(blob);
  lenke.download = filnavn;
  document.body.appendChild(lenke);
  lenke.click();
  document.body.removeChild(lenke);
}

// Legg inn knappene litt etter oppstart.
// Rører ikke login.
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(leggTilLonnKnapperEtterLogin, 1000);
});

// Hvis appen bytter side etter login, prøv igjen når bruker klikker/trykker.
document.addEventListener("click", () => {
  setTimeout(leggTilLonnKnapperEtterLogin, 300);
});

console.log("Lønnstillegg lastet uten å endre login");
