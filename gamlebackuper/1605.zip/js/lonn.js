console.log("lonn.js er lastet");

let sisteLonnData = [];

function lonnMelding(tekst, erFeil = false) {
  const el = document.getElementById("lonnMelding");

  if (el) {
    el.textContent = tekst || "";
    el.style.color = erFeil ? "#b42318" : "#116329";
  }
}

function lonnTall(verdi) {
  if (verdi === null || verdi === undefined || verdi === "") return 0;

  const n = Number(String(verdi).replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

function lonnRund(n) {
  return Math.round((lonnTall(n) + Number.EPSILON) * 100) / 100;
}

function kroner(n) {
  return lonnRund(n).toLocaleString("no-NO", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function finnTimerAntall(rad) {
  return lonnTall(rad.timer || 0);
}

function hentAnsattNavn(ansatt, ansattId) {
  return (
    ansatt?.navn ||
    ansatt?.epost ||
    ansattId ||
    "Ukjent ansatt"
  );
}

function hentTimelonn(ansatt, timerad) {
  return lonnTall(
    ansatt?.timelonn ||
    timerad?.timepris ||
    0
  );
}

function beregnSkatt(brutto, ansatt) {

  const skattVerdi = lonnTall(
    ansatt?.skattetrekk ||
    ansatt?.skatteprosent
  );

  if (skattVerdi <= 0) return 0;

  if (skattVerdi <= 100) {
    return lonnRund(brutto * skattVerdi / 100);
  }

  return lonnRund(skattVerdi);
}

async function hentOgBeregnLonn() {

  const [timerRes, ansatteRes] = await Promise.all([
    supabaseClient.from("timer").select("*"),
    supabaseClient.from("ansatte").select("*")
  ]);

  if (timerRes.error) {
    throw new Error(timerRes.error.message);
  }

  if (ansatteRes.error) {
    throw new Error(ansatteRes.error.message);
  }

  const timerader = timerRes.data || [];
  const ansatte = ansatteRes.data || [];

  const ansatteMap = new Map(
    ansatte.map(a => [String(a.id), a])
  );

  const grupper = new Map();

  timerader.forEach(t => {

    const ansattId = String(t.ansatt_id || "");

    if (!ansattId) return;

    const ansatt = ansatteMap.get(ansattId) || {};

    if (!grupper.has(ansattId)) {

      grupper.set(ansattId, {
        ansatt,
        ansattNavn: hentAnsattNavn(ansatt, ansattId),
        kontonr: ansatt.kontonr || "",
        timer: 0,
        brutto: 0,
        skatt: 0,
        ekstraSkatt: lonnTall(ansatt.ekstra_skatt),
        andreTrekk: lonnTall(ansatt.andre_trekk),
        netto: 0
      });
    }

    const g = grupper.get(ansattId);

    const timer = finnTimerAntall(t);
    const timelonn = hentTimelonn(ansatt, t);

    g.timer += timer;
    g.brutto += timer * timelonn;
  });

  const resultat = Array.from(grupper.values()).map(g => {

    g.timer = lonnRund(g.timer);
    g.brutto = lonnRund(g.brutto);

    g.skatt = beregnSkatt(
      g.brutto,
      g.ansatt
    );

    g.netto = lonnRund(
      g.brutto -
      g.skatt -
      g.ekstraSkatt -
      g.andreTrekk
    );

    return g;
  });

  sisteLonnData = resultat;

  return resultat;
}

async function kjorLonn() {

  try {

    lonnMelding("Beregner lønn...");

    const data = await hentOgBeregnLonn();

    if (!data.length) {
      lonnMelding("Ingen timer funnet.", true);
      return;
    }

    lonnMelding("Lønn beregnet.");

  } catch (e) {

    console.error(e);
    lonnMelding(e.message, true);
  }
}

async function lagLonnsslipper(kopi = false) {

  try {

    const data = sisteLonnData.length
      ? sisteLonnData
      : await hentOgBeregnLonn();

    if (!window.jspdf || !window.jspdf.jsPDF) {
      alert("PDF bibliotek mangler");
      return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    data.forEach((r, index) => {

      if (index > 0) {
  doc.addPage();
}

let y = 70;

// LOGO
try {

  const logoUrl =
    window.location.origin +
    "/NyTimerdelt/bilder/logo.jpg";

  const logoWidth = 70;
  const logoHeight = 50;

  const x =
    (210 - logoWidth) / 2;

  doc.addImage(
    logoUrl,
    "JPEG",
    x,
    3,
    logoWidth,
    logoHeight
  );

} catch (logoFeil) {

  console.warn(
    "Logo feil",
    logoFeil
  );
}

      doc.setFontSize(16);

      doc.text(
        kopi
          ? "LØNNSAVREGNING - KOPI"
          : "LØNNSAVREGNING",
        20,
        y
      );

      y += 15;

      doc.setFontSize(10);

      doc.text(
        "Navn: " + r.ansattNavn,
        20,
        y
      );

      y += 8;

      doc.text(
        "Kontonr: " + (r.kontonr || ""),
        20,
        y
      );

      y += 12;

      doc.text(
        "Timer",
        20,
        y
      );

      doc.text(
        String(r.timer),
        80,
        y
      );

      doc.text(
        kroner(r.brutto) + " kr",
        130,
        y
      );

      y += 10;

      doc.text(
        "Skatt",
        20,
        y
      );

      doc.text(
        "- " + kroner(r.skatt) + " kr",
        130,
        y
      );

      y += 10;

      doc.text(
        "Andre trekk",
        20,
        y
      );

      doc.text(
        "- " + kroner(r.andreTrekk) + " kr",
        130,
        y
      );

      y += 15;

      doc.line(
        20,
        y,
        190,
        y
      );

      y += 10;

      doc.setFontSize(12);

      doc.text(
        "Netto utbetalt",
        20,
        y
      );

      doc.text(
        kroner(r.netto) + " kr",
        130,
        y
      );
    });

    doc.save(
      kopi
        ? "lonnsslipper_kopi.pdf"
        : "lonnsslipper.pdf"
    );

    lonnMelding(
      "Lønnsslipper laget."
    );

  } catch (e) {

    console.error(e);
    lonnMelding(
      e.message,
      true
    );
  }
}

function lagRegneark(
  filnavn,
  arkNavn,
  rader
) {

  if (!window.XLSX) return;

  const ws =
    XLSX.utils.json_to_sheet(rader);

  const wb =
    XLSX.utils.book_new();

  XLSX.utils.book_append_sheet(
    wb,
    ws,
    arkNavn
  );

  XLSX.writeFile(
    wb,
    filnavn
  );
}

async function eksporterTrekkExcel() {

  const data =
    sisteLonnData.length
      ? sisteLonnData
      : await hentOgBeregnLonn();

  lagRegneark(
    "trekk.xlsx",
    "Trekk",
    data
  );
}

async function eksporterUtbetalingerExcel() {

  const data =
    sisteLonnData.length
      ? sisteLonnData
      : await hentOgBeregnLonn();

  lagRegneark(
    "utbetalinger.xlsx",
    "Utbetalinger",
    data
  );
}
function lagLonnsslipperKopi() {
  return lagLonnsslipper(true);
}

window.kjorLonn =
  kjorLonn;

window.lagLonnsslipper =
  lagLonnsslipper;

window.eksporterTrekkExcel =
  eksporterTrekkExcel;

window.eksporterUtbetalingerExcel =
  eksporterUtbetalingerExcel;

window.hentOgBeregnLonn =
  hentOgBeregnLonn;
  window.lagLonnsslipperKopi = lagLonnsslipperKopi;
  