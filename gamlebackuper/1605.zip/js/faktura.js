const MVA_SATS = 0.25;
const LOGO_URL = window.location.origin + "/NyTimerdelt/logo.jpg";

function formatBelop(verdi) {
  return Number(verdi || 0).toLocaleString("no-NO", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function tryggFilnavn(tekst) {
  return String(tekst || "faktura")
    .toLowerCase()
    .replace(/[æ]/g, "ae")
    .replace(/[ø]/g, "o")
    .replace(/[å]/g, "a")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function formatDatoISO(dato) {
  return dato.toISOString().slice(0, 10);
}

function leggTilDager(dato, dager) {
  const nyDato = new Date(dato);
  nyDato.setDate(nyDato.getDate() + dager);
  return nyDato;
}

function hentValgtMaaned() {
  const datoFelt = document.getElementById("dato");
  const dato = datoFelt && datoFelt.value
    ? datoFelt.value
    : new Date().toISOString().slice(0, 10);

  return dato.slice(0, 7);
}

function hentValgtKunde() {
  const kundeValg = document.getElementById("kundeValg");

  if (!kundeValg || !kundeValg.value) {
    return null;
  }

  const valgtId = String(kundeValg.value);

  return (window.kunder || []).find(k =>
    String(k.id || "") === valgtId ||
    String(k.kundenr || "") === valgtId
  ) || null;
}

async function hentFirmaData() {
  try {
    const { data, error } =
      await supabaseClient
        .from("firma")
        .select("*")
        .limit(1)
        .maybeSingle();

    if (error) {
      console.warn("Firma-feil:", error);
    }

    return data || {};
  } catch (e) {
    console.warn("Kunne ikke hente firma:", e);
    return {};
  }
}

function hentKundeNr(kunde, time) {
  return String(
    kunde?.kundenr ||
    kunde?.kunde_nr ||
    kunde?.id ||
    time?.kunde_nr ||
    time?.kundeNr ||
    time?.kunde_id ||
    ""
  );
}

function hentKundeNavn(kunde, time) {
  return String(
    kunde?.navn ||
    time?.kunde_navn ||
    time?.kundeNavn ||
    time?.kunde ||
    "Kunde"
  );
}

function finnKundeForTime(time) {
  const kunder = window.kunder || [];

  return kunder.find(k =>
    String(k.id || "") === String(time.kunde_id || "") ||
    String(k.kundenr || "") === String(time.kunde_nr || time.kundeNr || "") ||
    String(k.navn || "").toLowerCase() ===
      String(time.kunde_navn || time.kundeNavn || time.kunde || "").toLowerCase()
  ) || null;
}

function erSammeKunde(time, kunde) {
  if (!kunde) return true;

  return (
    String(time.kunde_id || "") === String(kunde.id || "") ||
    String(time.kunde_nr || time.kundeNr || "") === String(kunde.kundenr || kunde.id || "") ||
    String(time.kunde_navn || time.kundeNavn || time.kunde || "").toLowerCase() ===
      String(kunde.navn || "").toLowerCase()
  );
}

function erAlleredeFakturert(time) {
  return (
    time.fakturerbar === false ||
    time.fakturert === true ||
    time.faktura_id ||
    time.fakturanr ||
    time.fakturert_dato
  );
}

function beregnSumEksMvaForTime(time) {
  if (
    time.sum !== undefined &&
    time.sum !== null &&
    Number(time.sum) > 0
  ) {
    return Number(time.sum);
  }

  return Number(time.timer || 0) * Number(time.timepris || 0);
}

function beregnMvaLinje(time) {
  const sumEksMva = beregnSumEksMvaForTime(time);
  const mva = sumEksMva * MVA_SATS;
  const sumInkMva = sumEksMva + mva;

  return {
    sumEksMva,
    mva,
    sumInkMva
  };
}

function summerTimerMedMva(timerListe) {
  return timerListe.reduce(
    (acc, t) => {
      const linje = beregnMvaLinje(t);

      acc.sumEksMva += linje.sumEksMva;
      acc.mva += linje.mva;
      acc.sumInkMva += linje.sumInkMva;

      return acc;
    },
    {
      sumEksMva: 0,
      mva: 0,
      sumInkMva: 0
    }
  );
}

function grupperTimerPerKunde(timerListe) {
  const grupper = new Map();

  timerListe.forEach(t => {
    const kunde =
      finnKundeForTime(t) || {
        id: t.kunde_id || t.kunde_nr || t.kunde_navn || "kunde",
        kundenr: t.kunde_nr || t.kunde_id || "",
        navn: t.kunde_navn || t.kunde || "Kunde",
        adresse: "",
        postadresse: ""
      };

    const key = String(kunde.id || kunde.kundenr || kunde.navn || "kunde");

    if (!grupper.has(key)) {
      grupper.set(key, {
        kunde,
        timer: []
      });
    }

    grupper.get(key).timer.push(t);
  });

  return Array.from(grupper.values());
}

async function hentLogoBase64() {
  return await new Promise(resolve => {
    const img = new Image();

    img.crossOrigin = "anonymous";

    img.onload = function () {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;

        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0);

        resolve(canvas.toDataURL("image/jpeg", 0.92));
      } catch (e) {
        alert("Logo kunne ikke konverteres: " + (e.message || e));
        resolve(null);
      }
    };

    img.onerror = function () {
      alert("Logo kunne ikke lastes fra: " + LOGO_URL);
      resolve(null);
    };

    img.src = LOGO_URL + "?v=" + Date.now();
  });
}

async function leggTilLogo(doc) {
  try {
    const logoBase64 = await hentLogoBase64();

    if (!logoBase64) {
      alert("Fant ikke logo.");
      return false;
    }

    const img = new Image();
    img.src = logoBase64;

    await new Promise(resolve => {
      img.onload = resolve;
    });

    const ratio = img.width / img.height;
    const bredde = 70;
    const hoyde = bredde / ratio;

    const sidebredde = doc.internal.pageSize.getWidth();
    const x = (sidebredde - bredde) / 2;

    doc.addImage(
      logoBase64,
      "JPEG",
      x,
      3,
      bredde,
      hoyde
    );

    return true;
  } catch (e) {
    alert("Kunne ikke legge logo på PDF: " + (e.message || e));
    console.error(e);
    return false;
  }
}

async function sperrFakturerteTimer(timerListe, fakturanr) {
  const ider =
    timerListe
      .map(t => t.id)
      .filter(Boolean);

  timerListe.forEach(t => {
    t.fakturerbar = false;
    t.fakturert = true;
    t.fakturanr = fakturanr;
    t.fakturert_dato = new Date().toISOString();
  });

  if (!ider.length) {
    return true;
  }

  try {
    const { error } =
      await supabaseClient
        .from("timer")
        .update({
          fakturerbar: false,
          fakturert: true,
          fakturanr: fakturanr,
          fakturert_dato: new Date().toISOString()
        })
        .in("id", ider);

    if (error) {
      console.warn("Kunne ikke sperre fakturerte timer:", error);
      return false;
    }

    return true;
  } catch (e) {
    console.warn("Kunne ikke sperre fakturerte timer:", e);
    return false;
  }
}

async function lagEnFakturaPdf(
  kunde,
  fakturaTimer,
  maaned,
  firma,
  erKopi = false,
  eksisterendeFakturanr = null
) {
  const jspdfObj = window.jspdf;

  if (!jspdfObj || !jspdfObj.jsPDF) {
    alert("PDF-biblioteket er ikke lastet.");
    return;
  }

  const doc = new jspdfObj.jsPDF();

  const summer = summerTimerMedMva(fakturaTimer);
  const fakturaDato = new Date();
  const forfallsDato = leggTilDager(fakturaDato, 14);

  const fakturanr =
    eksisterendeFakturanr ||
    fakturaTimer[0]?.fakturanr ||
    fakturaTimer[0]?.faktura_nr ||
    (
      "F-" +
      formatDatoISO(fakturaDato).replaceAll("-", "") +
      "-" +
      Math.floor(Math.random() * 9000 + 1000)
    );

  await leggTilLogo(doc);

  let y = 90;

  doc.setFontSize(20);
  doc.text("FAKTURA", 14, y);

  if (erKopi) {
    doc.setFontSize(16);
    doc.text("KOPI", 165, y);
  }

  let hoyreY = 95;

  doc.setFontSize(10);

  doc.text("Forfallsdato", 140, hoyreY);
  doc.text(formatDatoISO(forfallsDato), 175, hoyreY);

  hoyreY += 6;

  doc.text("Kontonr", 140, hoyreY);
  doc.text(firma.kontonr || "", 175, hoyreY);

  hoyreY += 6;

  doc.text("Fakturanr", 140, hoyreY);
  doc.text(fakturanr, 175, hoyreY);

  hoyreY += 6;

  doc.text("Dato", 140, hoyreY);
  doc.text(formatDatoISO(fakturaDato), 175, hoyreY);

  hoyreY += 6;

  doc.text("Kundenr", 140, hoyreY);
  doc.text(hentKundeNr(kunde, fakturaTimer[0]), 175, hoyreY);

  y += 25;

  doc.setFontSize(12);
  doc.text(hentKundeNavn(kunde, fakturaTimer[0]), 14, y);

  y += 6;

  doc.setFontSize(10);

  if (kunde && kunde.adresse) {
    doc.text(kunde.adresse, 14, y);
    y += 5;
  }

  if (kunde && kunde.postadresse) {
    doc.text(kunde.postadresse, 14, y);
    y += 5;
  }

  y += 10;

  doc.text("Dato", 14, y);
  doc.text("Beskrivelse", 45, y);
  doc.text("Timer", 120, y);
  doc.text("Eks mva", 145, y);
  doc.text("MVA", 170, y);

  y += 4;

  doc.line(14, y, 195, y);

  y += 7;

  fakturaTimer.forEach(t => {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }

    const linje = beregnMvaLinje(t);
    const tekst = String(t.beskrivelse || t.kommentar || "Timer").slice(0, 40);

    doc.text(String(t.dato || ""), 14, y);
    doc.text(tekst, 45, y);
    doc.text(String(t.timer || 0), 120, y);
    doc.text(formatBelop(linje.sumEksMva), 145, y);
    doc.text(formatBelop(linje.mva), 170, y);

    y += 6;
  });

  y += 4;

  doc.line(120, y, 195, y);

  y += 8;

  doc.setFontSize(11);

  doc.text("Sum eks mva:", 130, y);
  doc.text(formatBelop(summer.sumEksMva) + " kr", 170, y);

  y += 6;

  doc.text("MVA 25%:", 130, y);
  doc.text(formatBelop(summer.mva) + " kr", 170, y);

  y += 6;

  doc.setFontSize(12);

  doc.text("Sum inkl mva:", 130, y);
  doc.text(formatBelop(summer.sumInkMva) + " kr", 170, y);

  doc.setFontSize(9);

  doc.text(firma.navn || "", 14, 285);
  doc.text(firma.adresse || "", 70, 285);
  doc.text(firma.postadresse || "", 120, 285);
  doc.text("MVA: " + (firma.mva_nr || ""), 170, 285);

  const filnavn =
    `${tryggFilnavn(hentKundeNavn(kunde, fakturaTimer[0]))}_${maaned}${erKopi ? "_KOPI" : ""}.pdf`;
 const antallSider = doc.getNumberOfPages();

for (let i = 1; i <= antallSider; i++) {

  doc.setPage(i);

  doc.setFontSize(9);

  doc.text(
    "Side " + i + " av " + antallSider,
    170,
    290
  );

  doc.save(filnavn);
 }

  if (!erKopi) {
    await sperrFakturerteTimer(fakturaTimer, fakturanr);
  }
}

async function lagFakturaPdf() {
  const melding = document.getElementById("timerMelding");

  try {
    const maaned = hentValgtMaaned();
    const firma = await hentFirmaData();
    const valgtKunde = hentValgtKunde();

    const timerForMaaned =
      (window.timer || [])
        .filter(t => !erAlleredeFakturert(t))
        .filter(t => String(t.dato || "").slice(0, 7) === maaned)
        .filter(t => erSammeKunde(t, valgtKunde));

    if (!timerForMaaned.length) {
      if (melding) {
        melding.textContent =
          "Fant ingen fakturerbare timer. De kan allerede være fakturert.";
      }

      return;
    }

    const grupper = grupperTimerPerKunde(timerForMaaned);

    for (const gruppe of grupper) {
      await lagEnFakturaPdf(
        gruppe.kunde,
        gruppe.timer,
        maaned,
        firma,
        false
      );
    }

    if (melding) {
      melding.textContent =
        "Faktura PDF laget. Timene er sperret mot ny fakturering.";
    }

    if (typeof fyllKreditnotaFakturaValg === "function") {
      fyllKreditnotaFakturaValg();
    }
  } catch (e) {
    const feiltekst =
      "Faktura feilet: " +
      (e && e.message ? e.message : String(e));

    console.error("Faktura feilet:", e);

    if (melding) {
      melding.textContent = feiltekst;
    }

    alert(feiltekst);
  }
}
function fyllFakturaKopiValg() {

  const select =
    document.getElementById("fakturaKopiValg");

  if (!select) {
    return;
  }

  select.innerHTML =
    '<option value="">Velg faktura</option>';

  const fakturaer = [...new Set(

    (window.timer || [])
      .map(t => t.fakturanr || t.faktura_nr)
      .filter(Boolean)

  )];

  fakturaer.forEach(nr => {

    const option =
      document.createElement("option");

    option.value = nr;
    option.textContent = nr;

    select.appendChild(option);
  });
}

function hentFakturaKopiSelect() {
  return (
    document.getElementById("fakturaKopiValg") ||
    document.getElementById("fakturaKopiFakturaValg") ||
    document.getElementById("kreditnotaFakturaValg")
  );
}

function hentValgtFakturanrForKopi() {
  const select = hentFakturaKopiSelect();

  if (!select) {
    return "";
  }

  let verdi = String(select.value || "").trim();

  if (!verdi && select.selectedIndex >= 0) {
    verdi = String(select.options[select.selectedIndex].text || "").trim();
  }

  return verdi;
}

async function lagFakturaKopiPdf() {
  const omrade = document.getElementById("kreditnotaOmrade");
  const select = hentFakturaKopiSelect();
  const melding = document.getElementById("timerMelding");

  if (!select) {
    alert("Fant ikke nedtrekksliste for faktura.");
    return;
  }

  const fakturanr = hentValgtFakturanrForKopi();

  if (!fakturanr) {
    alert("Velg faktura først.");
    return;
  }

  try {
    if (melding) {
      melding.textContent = "Starter utskrift av fakturakopi...";
    }

    console.log("Valgt faktura for kopi:", fakturanr);

    const kopiTimer = (window.timer || []).filter(t => {
      const nr = String(t.fakturanr || t.faktura_nr || "").trim();
      return nr === fakturanr;
    });

    console.log("Timer funnet på faktura:", kopiTimer);

    if (!kopiTimer.length) {
      alert("Fant ingen timer på valgt faktura: " + fakturanr);
      return;
    }

    const firma = await hentFirmaData();
    const kunde = finnKundeForTime(kopiTimer[0]) || null;
    const maaned = String(kopiTimer[0].dato || new Date().toISOString()).slice(0, 7);

    await lagEnFakturaPdf(
      kunde,
      kopiTimer,
      maaned,
      firma,
      true,
      fakturanr
    );

    if (omrade) {
      omrade.style.display = "none";
    }

    if (melding) {
      melding.textContent = "Fakturakopi laget.";
    }

  } catch (e) {
    console.error("Fakturakopi feilet:", e);
    alert("Fakturakopi feilet: " + (e.message || e));
  }
}
function kobleFakturaKnapp() {
  const pdfKnapp = document.getElementById("pdfKnapp");

  if (!pdfKnapp) {
    console.warn("Fant ikke pdfKnapp");
    return;
  }

  pdfKnapp.onclick = async function () {
    await lagFakturaPdf();
  };
}

function kobleFakturaKopiKnapp() {
  const kopiKnapp = document.getElementById("fakturaKopiKnapp");
  const skrivUtKopiKnapp = document.getElementById("skrivUtFakturaKopiKnapp");

  if (kopiKnapp) {
    kopiKnapp.onclick = function () {
      const kopiOmrade = document.getElementById("fakturaKopiOmrade");
      const kreditOmrade = document.getElementById("kreditnotaOmrade");

      if (kreditOmrade) kreditOmrade.style.display = "none";
      if (kopiOmrade) kopiOmrade.style.display = "block";

      fyllFakturaKopiValg();
    };
  }

  if (skrivUtKopiKnapp) {
    skrivUtKopiKnapp.onclick = async function () {
      await lagFakturaKopiPdf();
    };
  }
}

function kobleKreditnotaVisning() {
  const kreditKnapp = document.getElementById("kreditnotaKnapp");

  if (kreditKnapp) {
    kreditKnapp.onclick = function () {
      const kopiOmrade = document.getElementById("fakturaKopiOmrade");
      const kreditOmrade = document.getElementById("kreditnotaOmrade");

      if (kopiOmrade) kopiOmrade.style.display = "none";
      if (kreditOmrade) kreditOmrade.style.display = "block";

      if (typeof fyllKreditnotaFakturaValg === "function") {
        fyllKreditnotaFakturaValg();
      }
    };
  }
}

kobleFakturaKopiKnapp();
kobleKreditnotaVisning();
function fyllKreditnotaFakturaValg() {
  const select =
    document.getElementById("kreditnotaFakturaValg");

  if (!select) {
    return;
  }

  select.innerHTML =
    '<option value="">Velg faktura å kreditere</option>';

  const fakturaer = [...new Set(
    (window.timer || [])
      .map(t => t.fakturanr || t.faktura_nr)
      .filter(Boolean)
  )];

  fakturaer.forEach(nr => {
    const option = document.createElement("option");

    option.value = nr;
    option.textContent = nr;

    select.appendChild(option);
  });
}

async function lagKreditnotaPdf() {

  const select =
    document.getElementById("kreditnotaFakturaValg");

  if (!select || !select.value) {
    alert("Velg faktura først.");
    return;
  }

  const fakturanr = select.value;

  const kreditTimer =
    (window.timer || []).filter(t =>
      String(t.fakturanr || t.faktura_nr || "") === fakturanr
    );

  if (!kreditTimer.length) {
    alert("Fant ingen timer.");
    return;
  }

  const firma = await hentFirmaData();

  const kunde =
    finnKundeForTime(kreditTimer[0]) || null;

  const maaned =
    String(
      kreditTimer[0].dato ||
      new Date().toISOString()
    ).slice(0, 7);

  await lagEnFakturaPdf(
    kunde,
    kreditTimer,
    maaned,
    firma,
    true,
    "KREDIT-" + fakturanr
  );

  alert("Kreditnota laget.");
}

function kobleKreditnotaKnapp() {

  const knapp =
    document.getElementById("skrivUtKreditnotaKnapp");

  if (!knapp) {
    return;
  }

  knapp.onclick = async function () {
    await lagKreditnotaPdf();
  };
}

kobleKreditnotaKnapp();
