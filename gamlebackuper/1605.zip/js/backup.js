async function hentBackupData() {
  const tabeller = ["firma", "ansatte", "kunder", "timer", "trekk_typer", "ansatt_trekk", "fakturaer"];

  const data = {
    dato: new Date().toISOString(),
    versjon: "1.0",
    tabeller: {}
  };

  for (const tabell of tabeller) {
    const { data: rader, error } = await supabaseClient
      .from(tabell)
      .select("*");

    data.tabeller[tabell] = {
      feil: error ? error.message : null,
      rader: rader || []
    };
  }

  return data;
}

async function lagreBackupFil(data, prefix = "backup_timeregistrering") {
  const tekst = JSON.stringify(data, null, 2);
  const filnavn = prefix + "_" + new Date().toISOString().replace(/[:.]/g, "-") + ".json";
  const blob = new Blob([tekst], { type: "application/json" });

  if (window.showSaveFilePicker) {
    const fil = await window.showSaveFilePicker({
      suggestedName: filnavn,
      types: [
        {
          description: "JSON backup",
          accept: { "application/json": [".json"] }
        }
      ]
    });

    const stream = await fil.createWritable();
    await stream.write(blob);
    await stream.close();
    return;
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filnavn;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

async function backup() {
  try {
    const data = await hentBackupData();
    await lagreBackupFil(data, "backup_timeregistrering");
    alert("Backup er lagret.");
  } catch (feil) {
    console.error(feil);
    alert("Feil ved backup: " + feil.message);
  }
}

async function importerBackup(event) {
  try {
    const fil = event.target.files[0];

    if (!fil) {
      alert("Ingen fil valgt.");
      return;
    }

    const tekst = await fil.text();
    const backupData = JSON.parse(tekst);

    if (!backupData.tabeller) {
      alert("Dette ser ikke ut som en gyldig backupfil.");
      return;
    }

    const bekreft = confirm(
      "Restore vil legge inn/oppdatere data fra backupfilen.\n\n" +
      "Eksisterende rader med samme ID blir overskrevet.\n" +
      "Nye rader legges til.\n\n" +
      "Systemet tar nødbackup først.\n\n" +
      "Vil du fortsette?"
    );

    if (!bekreft) {
      event.target.value = "";
      return;
    }

    const nodbackup = await hentBackupData();
    await lagreBackupFil(nodbackup, "NODBACKUP_for_restore");

    const rekkefolge = ["firma", "ansatte", "kunder", "timer", "trekk_typer", "ansatt_trekk", "fakturaer"];

    for (const tabell of rekkefolge) {
      const pakke = backupData.tabeller[tabell];

      if (!pakke || !Array.isArray(pakke.rader) || pakke.rader.length === 0) {
        continue;
      }

      const { error } = await supabaseClient
        .from(tabell)
        .upsert(pakke.rader, { onConflict: "id" });

      if (error) {
        throw new Error("Feil ved restore av " + tabell + ": " + error.message);
      }
    }

    alert("Restore er ferdig.");
    event.target.value = "";
    location.reload();

  } catch (feil) {
    console.error(feil);
    alert("Feil ved restore: " + feil.message);
  }
}

window.backup = backup;
window.importerBackup = importerBackup;